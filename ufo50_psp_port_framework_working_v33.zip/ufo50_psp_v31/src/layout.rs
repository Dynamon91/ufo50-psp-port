//! Fixed-point Android -> PSP 480x272 layout transform.
//! Coordinates are kept in integer/fixed-point form to avoid floating-point
//! work in the render loop.

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub struct Rect { pub x:i32, pub y:i32, pub w:i32, pub h:i32 }

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub struct Viewport {
    pub x: i32, pub y: i32, pub w: i32, pub h: i32,
    pub scale_16_16: i32,
}

pub fn fit(src_w:i32, src_h:i32, dst_w:i32, dst_h:i32) -> Option<Viewport> {
    if src_w <= 0 || src_h <= 0 || dst_w <= 0 || dst_h <= 0 { return None; }
    let sx = ((dst_w as i64) << 16) / src_w as i64;
    let sy = ((dst_h as i64) << 16) / src_h as i64;
    let scale = sx.min(sy);
    let w = ((src_w as i64 * scale) >> 16) as i32;
    let h = ((src_h as i64 * scale) >> 16) as i32;
    Some(Viewport {
        x:(dst_w-w)/2, y:(dst_h-h)/2, w, h,
        scale_16_16:scale as i32
    })
}

pub fn map_point(x:i32,y:i32,v:Viewport)->(i32,i32) {
    let px=((x as i64*v.scale_16_16)>>16) as i32 + v.x;
    let py=((y as i64*v.scale_16_16)>>16) as i32 + v.y;
    (px,py)
}

pub fn clamp_rect(mut r:Rect,dst_w:i32,dst_h:i32)->Rect {
    r.x=r.x.max(0).min(dst_w);
    r.y=r.y.max(0).min(dst_h);
    r.w=r.w.max(0).min(dst_w-r.x);
    r.h=r.h.max(0).min(dst_h-r.y);
    r
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test] fn widescreen_fit_is_exact() {
        let v=fit(854,480,480,272).unwrap();
        assert!(v.w<=480 && v.h<=272 && v.x>=0 && v.y>=0);
    }
    #[test] fn portrait_is_letterboxed() {
        let v=fit(480,854,480,272).unwrap();
        assert_eq!(v.w,152); assert_eq!(v.x,164); assert_eq!(v.y,0);
    }
    #[test] fn point_mapping_is_deterministic() {
        let v=fit(480,272,480,272).unwrap();
        assert_eq!(map_point(479,271,v),(479,271));
    }
}
