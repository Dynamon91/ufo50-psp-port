//! PSP VRAM budgeting primitives.
//! Estimates common 16-bit formats and rejects a batch that exceeds a
//! configurable conservative budget.

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum PixelFormat { Rgba4444, Rgb565, Indexed4, Indexed8 }

impl PixelFormat {
    pub const fn bytes_per_pixel_x16(self) -> u32 {
        match self { Self::Rgba4444|Self::Rgb565 => 16, Self::Indexed4 => 2, Self::Indexed8 => 8 }
    }
}

pub const fn texture_bytes(width:u32,height:u32,format:PixelFormat)->u64 {
    (width as u64 * height as u64 * format.bytes_per_pixel_x16() as u64 + 15) / 16
}

pub fn batch_fits(items:&[(u32,u32,PixelFormat)], budget:u64)->bool {
    items.iter().map(|&(w,h,f)| texture_bytes(w,h,f)).sum::<u64>() <= budget
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test] fn rgba4444_is_two_bytes() { assert_eq!(texture_bytes(64,64,PixelFormat::Rgba4444),8192); }
    #[test] fn indexed4_is_quarter_rgba() { assert_eq!(texture_bytes(64,64,PixelFormat::Indexed4),2048); }
    #[test] fn budget_rejects_overflow() {
        let x=[(256,256,PixelFormat::Rgba4444),(256,256,PixelFormat::Rgba4444)];
        assert!(!batch_fits(&x, 32*1024));
        assert!(batch_fits(&x, 128*1024));
    }
}
