//! PSP physical-input mapping for the game runtime.
//! Keeps platform-specific button semantics out of game logic.

#[derive(Clone, Copy, Debug, Default, PartialEq, Eq)]
pub struct ActionState {
    pub left: bool, pub right: bool, pub up: bool, pub down: bool,
    pub primary: bool, pub secondary: bool, pub skill_a: bool, pub skill_b: bool,
    pub page_prev: bool, pub page_next: bool, pub pause: bool, pub system: bool,
}

pub const PSP_SELECT:u32=0x000001;
pub const PSP_START:u32 =0x000008;
pub const PSP_UP:u32=0x000010;
pub const PSP_RIGHT:u32=0x000020;
pub const PSP_DOWN:u32=0x000040;
pub const PSP_LEFT:u32=0x000080;
pub const PSP_L:u32=0x000100;
pub const PSP_R:u32=0x000200;
pub const PSP_TRIANGLE:u32=0x001000;
pub const PSP_CIRCLE:u32=0x002000;
pub const PSP_CROSS:u32=0x004000;
pub const PSP_SQUARE:u32=0x008000;

pub fn map_buttons(buttons:u32)->ActionState {
    ActionState {
        left: buttons & PSP_LEFT != 0,
        right: buttons & PSP_RIGHT != 0,
        up: buttons & PSP_UP != 0,
        down: buttons & PSP_DOWN != 0,
        primary: buttons & PSP_CROSS != 0,
        secondary: buttons & PSP_CIRCLE != 0,
        skill_a: buttons & PSP_SQUARE != 0,
        skill_b: buttons & PSP_TRIANGLE != 0,
        page_prev: buttons & PSP_L != 0,
        page_next: buttons & PSP_R != 0,
        pause: buttons & PSP_START != 0,
        system: buttons & PSP_SELECT != 0,
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test] fn directional_mapping() {
        let a=map_buttons(PSP_LEFT|PSP_UP|PSP_CROSS);
        assert!(a.left && a.up && a.primary && !a.right);
    }
    #[test] fn action_mapping() {
        let a=map_buttons(PSP_CIRCLE|PSP_SQUARE|PSP_TRIANGLE|PSP_L|PSP_R|PSP_START|PSP_SELECT);
        assert!(a.secondary&&a.skill_a&&a.skill_b&&a.page_prev&&a.page_next&&a.pause&&a.system);
    }
}
