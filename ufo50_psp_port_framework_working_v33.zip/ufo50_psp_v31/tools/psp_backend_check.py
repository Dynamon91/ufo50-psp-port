#!/usr/bin/env python3
"""Report which Rust PSP backend a build environment can use."""
import os, shutil, json
def found(x): return shutil.which(x) is not None
def main():
    report={
      "rust": found("rustc"), "cargo": found("cargo"), "rustup": found("rustup"),
      "psp_config": found("psp-config"), "ppsspp": any(found(x) for x in ("PPSSPPWindows64.exe","ppsspp","PPSSPP")),
      "pspdev": bool(os.environ.get("PSPDEV")),
      "recommended_backend": "andrewaltimit/rust-psp" if found("cargo") else "pending-toolchain"
    }
    print(json.dumps(report,indent=2))
if __name__=="__main__": main()
