

## v27 — Rust PSP backend alignment

The build architecture now explicitly prefers the maintained AndrewAltimit Rust PSP fork when Cargo is available, while retaining the older rust-psp compatibility path. Added a deterministic backend/toolchain diagnostic.

**51% framework / 49% remaining.** This is not a playable-game percentage.


## v28 — Native layout transform

Added a fixed-point Android-resolution → PSP 480×272 viewport transform with centered letterboxing, deterministic coordinate mapping, clipping and unit tests for widescreen, portrait and 1:1 layouts.

**52% framework / 48% remaining.** Not a playable-game percentage.


## v29 — Texture VRAM budgeting

Added native-format texture byte estimation for RGBA4444, RGB565, Indexed4 and Indexed8, plus a bounded batch budget check and Rust regression tests. This provides the accounting layer needed before uploading textures to PSP EDRAM.

**53% framework / 47% remaining.** Not a playable-game percentage.


## v30 — Physical PSP input mapping

Added a platform-independent action layer mapping PSP digital buttons to movement, primary/secondary actions, skills, page shifting, pause and system actions. This keeps touch/virtual-control semantics out of game logic and is ready to be fed by `SceCtrlData` polling in the PSP adapter.

**54% framework / 46% remaining.** Not a playable-game percentage.
