# Rust PSP backend strategy

Primary backend: AndrewAltimit/rust-psp.
Compatibility/reference backend: overdrivenpotato/rust-psp.
Emulator validation target: PPSSPP.

The maintained fork is preferred because its repository describes it as a
modernized PSP SDK with Rust 2024 support, safety hardening, kernel-mode
support and optional std. The original rust-psp repository remains useful as
the API/reference baseline.

Do not claim a PSP build is successful until an EBOOT.PBP is produced and
actually boots in PPSSPP.
