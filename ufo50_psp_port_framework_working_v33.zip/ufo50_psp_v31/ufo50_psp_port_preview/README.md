# UFO 50 → PSP native port scaffold

This repository is the end-to-end *porting framework* for the supplied Android
APK. It is intentionally not described as a magically complete game conversion:
the APK contains a GameMaker `assets/ufo50/data.win` (~52.3 MiB) and 105 external
`.yytex` texture pages. Replacing the Android/GameMaker runtime with a native PSP
runtime requires translating GameMaker resources and implementing the game logic.

## Toolchain

- Rust nightly + `rust-src`
- `cargo-psp`
- `psp` (`rust-psp`) crate
- PSPSDK/PSPDEV for the native shim and optional classic PBP packaging
- Python 3 + Pillow

The upstream rust-psp project explicitly says it is a replacement SDK and does
not depend on PSPSDK. Therefore the architecture uses rust-psp for the Rust
application and PSPSDK-compatible C for the tiny hardware shim/packaging layer.

## Build

    cargo install cargo-psp
    rustup toolchain install nightly
    rustup component add rust-src --toolchain nightly
    make host-test
    make toolchain-check
    make release APK=/path/to/UFO-50.apk

The release target expects `cargo`, `rustup`, `cargo-psp`, and `psp-gcc` to be installed. It creates `dist/EBOOT.PBP` only when the expected cargo-psp output exists; this repository does not claim a build until that check passes.

## Asset pipeline

`tools/unpack_apk.py` extracts only the UFO 50 asset subtree. `convert_textures.py`
converts ordinary PNG/JPEG files and inventories `.yytex` pages. YYTex pages need
a real GameMaker texture-page decoder before their compressed payload can be
turned into PSP textures; treating them as PNG would corrupt the data.

The recommended runtime policy is texture streaming + a 4 MiB working VRAM
budget, not loading every page simultaneously.

## Runtime

The Rust side owns layout, input semantics and VFS policy. The PSPSDK C shim owns
the very small set of ABI-sensitive GU/controller operations. The display is
480×272 with a 512-pixel framebuffer stride, double-buffered GU lists, and
scissoring.

## Controls

D-pad/analog = movement/navigation
X = primary/confirm/jump
O = secondary/cancel
Square/Triangle = skills/attacks
L/R = previous/next tool/page
Start = pause
Select = system/options

The Android touch layer is not ported.

## Important limitation

An EBOOT can be built from this repository, but it is a porting shell until a
GameMaker resource translator/runtime is implemented. The supplied APK is not
an Android wrapper around a PSP-ready executable; it contains GameMaker data and
native Android libraries. The missing work is semantic translation, not merely
recompilation.


## 480x272 Screenshot Preview

The repository now includes `docs/preview_480x272.png`, a native-resolution visual preview of the current PSP port shell. It represents the implemented viewport/input/VFS/GE architecture; it is **not** a claim that the original UFO 50 gameplay renderer has already been fully reimplemented.

## Actual APK asset pass

A real conversion pass has now been run against the supplied APK: all **105 external `.yytex` texture pages** were decoded and converted to **512px-capped RGBA4444** raw pages. The resulting converted texture set is about **45.62 MiB** on disk. The source `data.win` was also parsed as a GameMaker `FORM/GEN8` container with **34 top-level chunks**, including `SPRT`, `SCPT`, `OBJT`, `ROOM`, `SHDR`, `FONT`, and `TAGS`.

The actual decoded first texture page is shown in `docs/preview_480x272_actual.png`. The PSP runtime should stream the VFS rather than map all texture pages into RAM simultaneously.

## Current Port Progress

See `docs/PORT_PROGRESS.md` for the current implementation percentage and component ledger.

The latest build also contains `docs/texture_montage_480_preview.png`, generated from decoded YYTex pages and displayed at PSP-native preview scale.

## Host-side validation (v10)

Run the FORM scanner regression suite from the repository root:

    python tools/test_scan_gm_form.py

Scan a GameMaker `data.win` file:

    python tools/scan_gm_form.py /path/to/data.win

The scanner treats FORM/chunk size fields as little-endian, checks declared
container bounds and chunk padding, and reports malformed chunk boundaries.
These checks validate archive structure only; they do not execute GML or prove
gameplay compatibility. See `docs/preview_480x272_v10.png` for the decoded
texture montage at the PSP's target resolution.


## v17 build and hardware fixes

- PSP framebuffers are now placed in EDRAM/VRAM via `sceGeEdramGetAddr()` rather than static main-RAM arrays. This fixes a likely black-screen/display-controller failure on actual hardware.
- Analog movement now uses a center-relative dead zone and supports negative and positive axes; D-pad movement is also wired into the preview shell.
- `main.rs` now includes the runtime module so the runtime bridge is actually part of the PSP crate.
- The build script now has explicit `host-test`, `toolchain-check`, `prepare-assets`, `assets`, `build`, and `release` targets; it fails with an actionable message when required tools or the APK are missing.
- These are source-level fixes. A PSP SDK, Rust toolchain, PPSSPP executable, and physical PSP are not present in the current build environment, so compilation and device behavior remain unverified.
