# v23 milestone: Emulator preflight validation

The emulator helper now has host-side behavior tests covering missing and empty EBOOT files, and ensuring a non-empty placeholder is not treated as proof of a successful boot. This does not test the PSP executable itself.

Run from the project root:

```sh
python3 tools/test_emulator_preflight.py
python3 tools/test_build_contract.py
python3 tools/test_scan_gm_form.py
make host-test
```

Rust/PSPSDK compilation, EBOOT generation, PPSSPP launch, visual boot confirmation, and PSP hardware validation remain outstanding.
