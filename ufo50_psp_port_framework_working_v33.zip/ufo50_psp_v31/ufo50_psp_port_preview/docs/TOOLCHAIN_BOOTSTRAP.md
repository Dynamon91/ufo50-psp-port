# Toolchain bootstrap

The current hosted workspace may have outbound DNS/network access disabled. In that case, `tools/bootstrap_rust_psp.sh` deliberately stops before installing anything and reports the unreachable official installer. It does not fake an installation.

On a network-enabled Linux environment, from this directory run:

```sh
./tools/bootstrap_rust_psp.sh
```

The script downloads the official rustup installer, installs a minimal nightly Rust toolchain, and installs `cargo-psp`. It does **not** install PSPSDK: PSPSDK setup is host-specific and must be completed separately. Set `PSPDEV` to the PSPSDK root and ensure `psp-gcc`, `psp-ar`, and `psp-config` are on `PATH`. Then run:

```sh
make toolchain-check
make host-test
make build
```

A successful prerequisite check is not proof that compilation succeeds. A successful build is not proof that the resulting EBOOT boots; use `make emulator-check` and then test with PPSSPP.
