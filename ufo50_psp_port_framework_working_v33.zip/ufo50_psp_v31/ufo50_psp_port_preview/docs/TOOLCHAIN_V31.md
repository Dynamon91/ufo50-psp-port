# v31 toolchain baseline

The Rust PSP backend now targets the modernized `AndrewAltimit/rust-psp` fork. Its documented build flow uses a Rust nightly toolchain with `rust-src` plus `cargo-psp`, and `cargo +nightly psp --release` generates `EBOOT.PBP` under the PSP target directory.

The repository's C/PSPSDK shim remains a separate compatibility layer. PSPSDK's `build.mak` is not required by the Rust crate itself because rust-psp is designed as an independent SDK replacement; the Makefile retains PSPSDK discovery for native shim work.

## Reproducible setup

```sh
rustup toolchain install nightly-2026-08-26
rustup component add rust-src --toolchain nightly-2026-08-26
cargo +nightly-2026-08-26 install cargo-psp
```

Then:

```sh
cd ufo50_psp_port_preview
cargo +nightly-2026-08-26 psp --release
```

Expected artifact:

`target/mipsel-sony-psp/release/EBOOT.PBP`

This is a build contract, not a claim that the current ChatGPT environment has the PSP toolchain installed or that gameplay is functional.
