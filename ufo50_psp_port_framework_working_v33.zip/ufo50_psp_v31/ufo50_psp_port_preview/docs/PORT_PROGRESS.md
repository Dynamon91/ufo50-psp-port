# UFO 50 → PSP Port Progress

**Overall estimated completion: 24%**

This percentage measures implemented port components, not elapsed time. It is intentionally conservative: a native bootable shell is not counted as completed gameplay.

| Area | Status |
|---|---:|
| APK/resource extraction & GameMaker analysis | 45% |
| YYTex texture decoding | 100% |
| PSP 16-bit texture conversion | 100% |
| VRAM/framebuffer architecture | 75% |
| 480×272 viewport/layout system | 70% |
| PSP physical input mapping | 90% |
| Streamed packed VFS | 70% |
| GameMaker data.win resource interpreter | 18% |
| GameMaker bytecode/runtime | 2% |
| Game/gameplay conversion | 0% |
| Audio | 5% |
| Final optimization | 10% |
| EBOOT/PPSSPP + real PSP validation | 0% |

## New work in this build

- Corrected the FORM scanner to begin at the actual first child chunk (`GEN8` at offset `0x08`); the previous scanner incorrectly treated the FORM type field as a separate field.
- Added a streamed Rust `datawin` reader that discovers all top-level GameMaker chunks through 8-byte header reads without loading the archive into RAM.
- Added a VFS range-read primitive in the PSP C shim and Rust wrapper.
- Added STRG extraction and resource-count generation: the supplied archive contains 76,784 strings, 9,907 object-event names, 1,343 script names, 18,025 CODE entries, 4,257 objects and 187 rooms.
- The build now copies `data.win` into the auxiliary VFS and validates the resulting archive.


- Reworked the PSP GU framebuffer path around two 512-stride RGB565 buffers so the 480×272 display does not consume the VRAM budget with oversized 32-bit framebuffers.
- Corrected PSP D-pad bit masks.
- Changed the VFS runtime from ordinary loose-file reads to a streamed lookup inside `assets/ufo50.vfs`; the complete payload is not loaded into RAM.
- Added VFS bounds validation and a host-side `validate_vfs.py` verifier.
- Current VFS contains 210 entries (105 texture pages plus metadata), about 45.63 MiB of payload.
- Added a 12-page decoded texture montage at native PSP preview scale.
- Added an explicit progress ledger so subsequent builds can update the same measurement.

## Important limitation

The GameMaker `data.win` is still not executable on PSP by itself. The remaining core task is to translate/execute its resources and bytecode through a PSP-native runtime. The existing Android native libraries are not treated as portable PSP binaries.


## v14 — Atomic event batch enqueue

Event queue capacity is preflighted before batch enqueue to avoid partial event lists. Added regression test for insufficient capacity.

## v16 — Safe live-event consumption

Added `Runtime::next_live_event`, which consumes FIFO events and discards stale calls whose instance is inactive or whose object mapping no longer matches. Added a regression test for despawned instances and mismatched object IDs. This is a dispatch-preparation step, not GML event execution. Rust compilation remains unverified in this environment because `cargo` and `rustc` are unavailable.


## v17 — Rust, display and packaging hardening

- Fixed a real `no_std` compile blocker in `gml_runtime.rs`: switched `std::collections::VecDeque` to `alloc::collections::VecDeque` and imported `alloc::vec::Vec`.
- Added `mod gml_runtime;` to the PSP binary so the runtime bridge is compiled into the application.
- Replaced main-RAM static framebuffers with PSP EDRAM-backed buffers.
- Corrected analog input to be center-relative with a dead zone, added D-pad cursor movement, and clamped the shell cursor to the screen.
- Replaced potentially unaligned MIPS reads of VFS index words with bytewise little-endian decoding. Added Memory Stick, PSP Go internal-storage, and relative-path VFS lookup attempts.
- Repaired build targets and host-test path; build now checks prerequisites and verifies the expected EBOOT output before copying it.
- Validation: 5/5 FORM scanner tests pass; packed VFS validates (210 files, 45.63 MiB payload); Python tool scripts compile. `cargo`, `rustc`, `psp-gcc`, and PPSSPP are not installed here, so Rust compile, C cross-compile, emulator launch, and real PSP testing remain unverified.
- Estimate: 44% framework engineering / 56% remaining. This is not gameplay compatibility.


## v18 — build/runtime safety pass

- Corrected the release target's misspelled fallback EBOOT path; the copy now uses the exact path checked by the build.
- Added explicit PSP GU packed-color conversion to avoid red/blue channel swaps.
- Exit the app if video/EDRAM initialization fails instead of entering a blank render loop.
- Bound-check FFI read lengths before setting Rust `Vec` lengths.
- Added four host-side build/runtime contract tests.
- Host checks: 5 GameMaker FORM scanner tests, 4 build/runtime contract tests, and VFS validation (210 files, 45.63 MiB payload) passed.
- Not verified: Rust compilation, EBOOT generation, PPSSPP boot, or real PSP hardware. Cargo/rustc/PSPSDK/PPSSPP are not installed in this environment.

## v20 — toolchain readiness diagnostics

- Expanded the prerequisite checker to detect `psp-config`, validate the `PSPDEV` directory, and recognize the alternate `PPSSPPHeadless` executable name.
- Added `--json` output for machine-readable toolchain status; distinguishes required compile tools from optional emulator validation.
- Added two regression tests for PSP-specific checks and the optional emulator distinction.
- Host checks: 5 FORM scanner tests + 8 build-contract tests passed; VFS validates (210 entries, 45.63 MiB payload); Python syntax checks passed.
- Not verified: network installation, Rust/C cross-compilation, EBOOT generation, PPSSPP boot, or real PSP hardware. This environment still lacks the required toolchain and cannot resolve the Rust download host.
- Estimate: 47% framework engineering / 53% remaining. This is not gameplay compatibility.

## v21 — PPSSPP preflight workflow

- Added an emulator preflight helper that verifies the EBOOT exists and is non-empty, discovers common PPSSPP executable names, and optionally requests launch.
- Added `make emulator-check` and `make emulator-launch` targets plus a PPSSPP test guide.
- The helper explicitly distinguishes launching an emulator process from visually verifying that the game boots; it does not report a successful boot on its own.
- Reference: official PPSSPP downloads at https://www.ppsspp.org/download/.
- Host validation: 5 FORM scanner tests, 10 build-contract tests, VFS validation and Python syntax checks are expected to run; actual EBOOT creation and PPSSPP boot remain blocked/unverified in this environment.
- Estimate: 48% framework engineering / 52% remaining. This is not gameplay compatibility.


## v22 — Exact runtime instance budgeting

- Fixed a runtime capacity contract bug: `Runtime::spawn` now enforces the configured `max_instances` rather than relying on allocator-reported `Vec::capacity()`, which is allowed to exceed the requested capacity.
- Added a Rust regression test proving that the configured instance budget is exact and that despawning does not silently recycle IDs or expand append-only storage.
- This is a source-level correctness improvement; Rust compilation remains unverified because the toolchain is not installed in this environment.
- Estimate: 48% framework engineering / 52% remaining; not a gameplay-completion percentage.


## v23 — Emulator preflight behavior tests

- Added executable tests for the PPSSPP preflight helper: missing EBOOT is rejected, zero-byte EBOOT is rejected, and a non-empty placeholder is reported only as preflight—not as a successful game boot.
- This hardens the validation workflow against false-positive build/emulator reports without requiring PPSSPP to be installed.
- Host validation: 5 FORM scanner tests + 10 build-contract tests + 3 emulator-preflight tests passed; Python syntax checks passed; VFS validates with 210 files and 45.63 MiB payload.
- Not verified: Rust compilation, EBOOT generation, PPSSPP boot, or real PSP hardware.
- Estimate: 49% framework engineering / 51% remaining. This is not a gameplay-completion percentage.

## v24 — Network-aware toolchain bootstrap

- Added `tools/bootstrap_rust_psp.sh` to check network access before downloading the official rustup installer, then install Rust nightly and `cargo-psp` when online.
- Added `make toolchain-bootstrap` and `docs/TOOLCHAIN_BOOTSTRAP.md` with explicit separation between Rust setup and the host-specific PSPSDK installation.
- Verified shell syntax, 5 GameMaker FORM scanner tests, 10 build-contract tests, and packed VFS validation (210 files, 45.63 MiB).
- This workspace still cannot resolve `sh.rustup.rs`; apt repository refresh also timed out. No toolchain was installed and no PSP build or emulator boot is claimed.
- Estimate: 49% framework engineering / 51% remaining. This is not a gameplay-completion percentage.

## v25 — Runtime capacity edge cases

- Added Rust unit tests for variable overwrite behavior under a full one-slot store and for zero-capacity event queues/stores.
- These tests are source-level only in this environment: `rustc`/Cargo are unavailable, so they have not been executed.
- EBOOT generation and PPSSPP boot remain unverified; full GameMaker bytecode execution and gameplay conversion are still outstanding.
- Estimate: 49% framework engineering / 51% remaining. This is not gameplay compatibility.

## v31 — Rust PSP toolchain baseline

- Switched the project dependency baseline to `AndrewAltimit/rust-psp`.
- Pinned the documented minimum nightly date in the toolchain instructions.
- Added an explicit `cargo-psp --release` → `mipsel-sony-psp` → `EBOOT.PBP` build contract.
- Kept PSPSDK available for the native C shim rather than incorrectly treating PSPSDK as a dependency of rust-psp.
- Removed proprietary game data from the source-only package intended for GitHub publication.

**55% framework engineering / 45% remaining.**

Not yet verified: PSP cross-compilation in this environment, EBOOT boot, PPSSPP runtime, real hardware, or original-game compatibility.

## v32 — Real PSP input path + build target

Corrected the PSP button masks used by the Rust runtime, wired the native shim to `sceCtrlReadBufferPositive`, and pinned the Rust nightly/toolchain contract. Added a Psp.toml and a stricter Makefile artifact check.

**58% framework engineering / 42% remaining.** This is not a percentage of the original game completed. EBOOT and PPSSPP remain unverified.
\n## v33 — Build contract and smoke-test cleanup\n\nImproved the Makefile to locate the actual cargo-psp EBOOT output instead of assuming one directory, added optional VFS validation, added emulator check/launch targets, and documented that preflight is not a boot test. Updated host-side build-contract regression tests.\n\n**59% framework engineering / 41% remaining.** The ChatGPT preparation environment lacks Rust/PSPDEV/PPSSPP tools, so EBOOT generation and emulator boot remain unverified. This percentage measures framework engineering only, not original-game completion.\n