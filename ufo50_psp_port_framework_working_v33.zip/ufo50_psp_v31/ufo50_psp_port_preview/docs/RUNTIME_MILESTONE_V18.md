# Runtime milestone v18 — build and display safety

## Changes

1. Fixed the release copy path so it matches the `target/mipsel-sony-psp/release/EBOOT.PBP` existence check.
2. Added explicit PSP GU packed color conversion (`0xAABBGGRR`, red in the low byte) for draw colors.
3. Added fail-fast behavior if `psp_video_init` cannot acquire/initialize its framebuffer.
4. Added Rust FFI result-length guards before calling `Vec::set_len`, preventing a C-side length larger than the allocation from being accepted.
5. Added host regression tests for these contracts and included them in `make host-test`.

## Validation

- GameMaker FORM scanner: 5/5 tests passed.
- Build/runtime contract: 4/4 tests passed.
- VFS: passed, 210 entries and 45.63 MiB payload.
- ZIP integrity is checked during packaging.
- Rust compilation, EBOOT generation, PPSSPP boot, and physical PSP testing are **not verified**: the environment does not have Cargo, rustc, PSPSDK, or PPSSPP available.

This milestone improves framework/build reliability. It does not make the original game playable yet.
