# Supplied APK inventory

Observed from the uploaded APK:

- ZIP entries: 757
- `assets/ufo50/data.win`: 54,792,908 bytes
- External `.yytex` pages: 105
- External `.yytex` total: 7,220,255 bytes
- PNG files: 55
- Native libraries include `libAPKVISION.so`, `libbutterscotch.so`, and Android
  architecture variants.
- The `assets/ufo50/` subtree also contains localized JSON text resources.

`data.win` begins with the GameMaker `FORM ... GEN8` signature. The port therefore
needs a GameMaker resource reader/translator rather than an Android UI wrapper.

This inventory is generated from the supplied APK; no files from the APK are
copied into the project archive.
