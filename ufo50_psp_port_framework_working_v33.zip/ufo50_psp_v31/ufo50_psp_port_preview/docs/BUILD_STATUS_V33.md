# v33 build status

The build scripts now discover `EBOOT.PBP` by filename after the cargo-psp command, validate that the artifact is non-empty, and expose PPSSPP preflight and launch targets.

Validation performed during packaging:
- `tools/test_scan_gm_form.py`: passed (5 tests).
- `tools/test_build_contract.py`: rerun after updates (see release log).
- Python source compilation: checked separately.
- Tool availability: `cargo`, `rustc`, `psp-gcc`, and PPSSPP were not present in this environment.

Consequently no PSP binary was generated here. A future successful build must produce `dist/EBOOT.PBP`, and PPSSPP boot/render must be checked separately.
