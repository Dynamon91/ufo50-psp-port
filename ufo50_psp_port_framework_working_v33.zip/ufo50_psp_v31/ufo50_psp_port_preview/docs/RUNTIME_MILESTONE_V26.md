# Runtime milestone v26 — reusable instance slots

## Change

The bounded runtime now reuses storage slots belonging to inactive instances. This avoids permanently exhausting the configured instance budget during repeated create/destroy cycles. Instance IDs remain monotonic and are not reused, so queued events containing an old ID cannot accidentally target a new instance occupying the same slot.

## Regression coverage

- A one-slot runtime can spawn, despawn, and spawn a replacement without growing its storage beyond the configured budget.
- The replacement receives a different stable ID.
- An event queued for the old instance is discarded after the storage slot is reused.

## Verification status

Host-side Python checks and VFS validation can run without the PSP toolchain. Rust unit tests were added/updated but could not be executed in this environment because `rustc` and Cargo are unavailable. PSP compilation, EBOOT generation, and PPSSPP boot remain unverified.
