# PPSSPP smoke testing

`make emulator-check` verifies that `dist/EBOOT.PBP` exists and checks whether a PPSSPP executable is installed. It is a preflight only; it does not claim that the game boots.

`make emulator-launch` asks a detected PPSSPP executable to open the EBOOT. A human must still confirm that the PSP shell starts and renders correctly. A successful process launch is not proof of gameplay compatibility.

## Current environment status

The ChatGPT build environment used for the v33 preparation did not have `cargo`, `rustc`, `psp-gcc`, or PPSSPP available. Therefore no EBOOT was built here and no emulator boot was performed.
