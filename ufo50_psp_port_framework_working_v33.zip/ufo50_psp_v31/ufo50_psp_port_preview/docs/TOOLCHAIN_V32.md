# v32 PSP build target

The project now pins the Rust PSP nightly in `rust-toolchain.toml` and uses `cargo-psp` to target `mipsel-sony-psp`. The modern `AndrewAltimit/rust-psp` documentation states that `cargo +nightly psp --release` produces `target/mipsel-sony-psp/release/EBOOT.PBP`. The native controller shim uses PSPSDK's `pspctrl.h` and `sceCtrlReadBufferPositive` to populate the portable Rust input sample.

This repository does not claim a successful cross-build from the ChatGPT runtime. A build is considered complete only after an actual `EBOOT.PBP` exists and boots in PPSSPP.

Recommended build:
```sh
rustup toolchain install nightly-2026-08-26
rustup component add rust-src --toolchain nightly-2026-08-26
cargo install cargo-psp
make release
```

PPSSPP supports command-line execution and a headless build for automated testing; the project can add that job once a reproducible PPSSPP runtime is available in CI.
