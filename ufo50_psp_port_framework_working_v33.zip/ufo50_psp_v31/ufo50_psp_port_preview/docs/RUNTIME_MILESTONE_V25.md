# v25 — Runtime capacity edge cases

This milestone adds source-level regression coverage for two bounded runtime contracts:

- Updating an existing variable changes its value without consuming another slot.
- Zero-capacity event queues and variable stores reject writes safely and remain empty.

The tests are Rust unit tests inside `src/gml_runtime.rs`. They are committed as source but **could not be executed here**, because `rustc` and Cargo are absent. Host-side Python checks and VFS validation are separate and do not prove that Rust compiles.

## Status

- Runtime source tests added: 2
- PSP compilation / EBOOT generation: blocked by missing Rust + PSPSDK
- PPSSPP boot: not tested
- GameMaker bytecode execution: still incomplete; this remains a porting framework, not a playable port.
