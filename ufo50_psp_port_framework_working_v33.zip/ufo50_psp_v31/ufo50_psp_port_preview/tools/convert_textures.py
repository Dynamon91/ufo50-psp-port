#!/usr/bin/env python3
"""Decode YYTex pages and produce PSP-friendly 16-bit textures.
Default: max 512x512 page, RGBA4444 raw LE words. The cap is configurable.
"""
import argparse,struct,subprocess,tempfile,shutil
import numpy as np
from pathlib import Path
from PIL import Image

def rgba4444(px):
    r,g,b,a=px; return ((a>>4)<<12)|((b>>4)<<8)|((g>>4)<<4)|(r>>4)

def rgb565(px):
    r,g,b,a=px; return ((r>>3)<<11)|((g>>2)<<5)|(b>>3)

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('src'); ap.add_argument('out'); ap.add_argument('--max',type=int,default=512); ap.add_argument('--format',choices=['rgba4444','rgb565'],default='rgba4444'); a=ap.parse_args()
    src,out=Path(a.src),Path(a.out); out.mkdir(parents=True,exist_ok=True)
    files=sorted(src.rglob('*.yytex')); total=0; pages=0
    for f in files:
        with tempfile.NamedTemporaryFile(suffix='.png') as t:
            subprocess.run(['python3',str(Path(__file__).with_name('yytex_unpack.py')),str(f),'-o',t.name],check=True,stdout=subprocess.DEVNULL)
            im=Image.open(t.name).convert('RGBA')
            scale=min(1.0,a.max/max(im.size)); size=(max(1,round(im.width*scale)),max(1,round(im.height*scale)))
            if size!=im.size: im=im.resize(size,Image.Resampling.LANCZOS)
            # GE-friendly raw pixels, no runtime PNG decoder required.
            arr=np.asarray(im,dtype=np.uint8)
            if a.format=='rgba4444':
                vals=((arr[:,:,3]>>4).astype(np.uint16)<<12)|((arr[:,:,2]>>4).astype(np.uint16)<<8)|((arr[:,:,1]>>4).astype(np.uint16)<<4)|(arr[:,:,0]>>4).astype(np.uint16)
            else:
                vals=(arr[:,:,0].astype(np.uint16)>>3)<<11 | (arr[:,:,1].astype(np.uint16)>>2)<<5 | (arr[:,:,2].astype(np.uint16)>>3)
            raw=vals.astype('<u2',copy=False).tobytes()
            rel=f.relative_to(src).with_suffix('.raw'); dest=out/rel; dest.parent.mkdir(parents=True,exist_ok=True); dest.write_bytes(raw)
            meta=dest.with_suffix('.meta'); meta.write_text(f'width={im.width}\nheight={im.height}\nformat={a.format}\nbytes={len(raw)}\n',encoding='utf8')
            total+=len(raw); pages+=1
    print(f'converted={pages} pages raw_bytes={total} (~{total/1024/1024:.2f} MiB)')
if __name__=='__main__': main()
