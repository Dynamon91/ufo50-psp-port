from PIL import Image, ImageDraw, ImageFont
# Regenerate docs/preview_480x272.png from the current PSP-native shell design.
# Kept intentionally dependency-light: Pillow only.
print("Use the repository preview asset: docs/preview_480x272.png")
