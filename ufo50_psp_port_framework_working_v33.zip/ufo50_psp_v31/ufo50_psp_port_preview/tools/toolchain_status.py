#!/usr/bin/env python3
"""Report host/PSP build prerequisites without pretending to install or build anything."""
import argparse
import json
import os
import shutil
import subprocess
import sys

TOOLS = {
    "python3": ["--version"],
    "rustc": ["--version"],
    "cargo": ["--version"],
    "rustup": ["--version"],
    "psp-gcc": ["--version"],
    "psp-ar": ["--version"],
    "psp-config": ["--pspsdk-version"],
    "ppsspp": ["--version"],
    "PPSSPPHeadless": ["--version"],
}
REQUIRED = {"rustc", "cargo", "rustup", "psp-gcc", "psp-ar", "psp-config"}


def describe(command, args):
    path = shutil.which(command)
    if not path:
        return {"path": None, "status": "MISSING"}
    try:
        result = subprocess.run([path, *args], text=True, stdout=subprocess.PIPE,
                                stderr=subprocess.STDOUT, timeout=3, check=False)
        first = next((line.strip() for line in result.stdout.splitlines() if line.strip()), "available")
        return {"path": path, "status": first[:140]}
    except (OSError, subprocess.TimeoutExpired) as exc:
        return {"path": path, "status": f"found; version check failed: {exc}"}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--require-psp", action="store_true", help="exit nonzero unless required build tools exist")
    parser.add_argument("--json", action="store_true", help="emit machine-readable diagnostics")
    args = parser.parse_args()
    checks = {name: describe(name, version_args) for name, version_args in TOOLS.items()}
    # PPSSPP is useful for validation but not required to compile an EBOOT.
    cargo_path = checks["cargo"]["path"]
    cargo_psp_ok = False
    if cargo_path:
        try:
            result = subprocess.run([cargo_path, "psp", "--help"], text=True,
                                    stdout=subprocess.PIPE, stderr=subprocess.STDOUT, timeout=5, check=False)
            cargo_psp_ok = result.returncode == 0
        except (OSError, subprocess.TimeoutExpired):
            pass
    pspdev = os.environ.get("PSPDEV")
    pspdev_ok = bool(pspdev and os.path.isdir(pspdev))
    missing = [name for name in sorted(REQUIRED) if not checks[name]["path"]]
    if not cargo_psp_ok:
        missing.append("cargo psp")
    if not pspdev_ok:
        missing.append("PSPDEV (valid directory environment variable)")
    report = {"tools": checks, "cargo_psp": "available" if cargo_psp_ok else "MISSING",
              "PSPDEV": {"value": pspdev, "valid_directory": pspdev_ok},
              "required_missing": missing, "build_ready": not missing}
    if args.json:
        print(json.dumps(report, indent=2, sort_keys=True))
    else:
        for name, result in checks.items():
            print(f"{name:16} {result['status']:10} {result['path'] or ''}")
        print(f"{'cargo psp':16} {'available' if cargo_psp_ok else 'MISSING'}")
        print(f"{'PSPDEV':16} {pspdev if pspdev_ok else 'MISSING/invalid'}")
        if missing:
            print("Missing required prerequisites: " + ", ".join(missing))
        if not args.require_psp:
            print("Diagnostic only: this command does not install tools or claim that a build succeeded.")
    if args.require_psp and missing:
        print("PSP BUILD BLOCKED: install/configure the listed prerequisites, then rerun `make toolchain-check`.", file=sys.stderr)
        return 2
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
