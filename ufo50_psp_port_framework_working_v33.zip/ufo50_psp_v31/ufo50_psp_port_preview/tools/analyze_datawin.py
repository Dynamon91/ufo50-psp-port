#!/usr/bin/env python3
"""GameMaker data.win scanner for the PSP port pipeline.

This intentionally parses the stable FORM/chunk envelope and the STRG table,
then emits a compact resource manifest. It does not pretend to execute GML.
"""
import argparse, json, re, struct
from pathlib import Path


def u32(b, off):
    return struct.unpack_from('<I', b, off)[0]


def scan_chunks(b):
    if b[:4] != b'FORM':
        raise ValueError('not a GameMaker FORM archive')
    declared = u32(b, 4)
    end = min(len(b), declared + 8)
    chunks = []
    p = 8
    while p + 8 <= end:
        tag = b[p:p+4].decode('latin1')
        size = u32(b, p + 4)
        data_start = p + 8
        data_end = data_start + size
        if data_end > end:
            raise ValueError(f'chunk {tag} overruns FORM boundary')
        chunks.append({'tag': tag, 'offset': p, 'data_offset': data_start, 'size': size})
        p = data_end
    return declared, chunks


def parse_strg(b, c):
    p = c['data_offset']
    end = p + c['size']
    if p + 4 > end:
        return []
    count = u32(b, p)
    table = p + 4
    if table + count * 4 > end:
        return []
    pointers = [u32(b, table + i * 4) for i in range(count)]
    out = []
    for i, off in enumerate(pointers):
        if off + 4 > len(b):
            continue
        n = u32(b, off)
        raw = b[off + 4: off + 4 + n]
        if off + 4 + n > len(b):
            continue
        try:
            text = raw.decode('utf-8')
        except UnicodeDecodeError:
            text = raw.decode('latin1', 'replace')
        out.append(text)
    return out


def count_u32(b, c):
    p = c['data_offset']
    return u32(b, p) if c['size'] >= 4 else None


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('datawin', type=Path)
    ap.add_argument('-o', '--output', type=Path, default=Path('datawin_manifest.json'))
    ap.add_argument('--strings', type=Path, help='optional STRG text output')
    a = ap.parse_args()
    b = a.datawin.read_bytes()
    declared, chunks = scan_chunks(b)
    by_tag = {c['tag']: c for c in chunks}

    strings = parse_strg(b, by_tag['STRG']) if 'STRG' in by_tag else []
    game_keys = sorted({int(m.group(1)) for s in strings for m in [re.match(r'game_name_(\d+)$', s)] if m})
    object_events = [s for s in strings if s.startswith('gml_Object_')]
    scripts = [s for s in strings if s.startswith('gml_Script_')]
    game_event_counts = {str(i): sum(1 for s in object_events if re.search(rf'(?<!\d)o{i}(?:_|$)', s)) for i in range(1, 52)}

    manifest = {
        'format': 'GameMaker FORM data.win',
        'file_size': len(b),
        'declared_form_size': declared,
        'chunk_count': len(chunks),
        'chunks': chunks,
        'resource_counts': {tag: count_u32(b, c) for tag, c in by_tag.items()},
        'strg': {'count': len(strings)},
        'game_name_keys': game_keys,
        'object_event_string_count': len(object_events),
        'script_string_count': len(scripts),
        'game_event_string_counts': game_event_counts,
    }
    a.output.parent.mkdir(parents=True, exist_ok=True)
    a.output.write_text(json.dumps(manifest, indent=2), encoding='utf-8')
    if a.strings:
        a.strings.parent.mkdir(parents=True, exist_ok=True)
        a.strings.write_text('\n'.join(strings) + '\n', encoding='utf-8')

    print(f'FORM: {len(b)/1048576:.2f} MiB; {len(chunks)} chunks; STRG={len(strings)}')
    print('chunks:', ' '.join(c['tag'] for c in chunks))
    print('game_name keys:', len(game_keys), game_keys[:5], '...', game_keys[-5:] if game_keys else [])
    print('object event names:', len(object_events), 'scripts:', len(scripts))

if __name__ == '__main__':
    main()
