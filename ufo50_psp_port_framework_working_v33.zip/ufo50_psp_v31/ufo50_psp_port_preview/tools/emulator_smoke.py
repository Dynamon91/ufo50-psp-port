#!/usr/bin/env python3
"""Check whether a non-empty PSP EBOOT and a PPSSPP executable are available.

This is a preflight only: it never claims the emulator booted the game. Use
--launch to start PPSSPP with the EBOOT, then visually confirm startup yourself.
"""
import argparse
import os
from pathlib import Path
import shutil
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]
DEFAULT_EBOOT = ROOT / "dist" / "EBOOT.PBP"
EMULATOR_NAMES = ("PPSSPPQt", "PPSSPPSDL", "PPSSPPHeadless", "PPSSPP", "ppsspp")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--eboot", type=Path, default=DEFAULT_EBOOT)
    parser.add_argument("--launch", action="store_true", help="launch detected PPSSPP with EBOOT; boot still requires visual confirmation")
    args = parser.parse_args()
    eboot = args.eboot.expanduser().resolve()
    if not eboot.is_file() or eboot.stat().st_size == 0:
        print(f"EBOOT MISSING/EMPTY: {eboot}", file=sys.stderr)
        return 2
    emulator = next((shutil.which(name) for name in EMULATOR_NAMES if shutil.which(name)), None)
    print(f"EBOOT: {eboot} ({eboot.stat().st_size} bytes)")
    if not emulator:
        print("PPSSPP: NOT FOUND (install from https://www.ppsspp.org/download/)")
        print("PREFLIGHT ONLY: EBOOT exists; emulator boot was not tested.")
        return 3
    print(f"PPSSPP: {emulator}")
    if not args.launch:
        print("PREFLIGHT ONLY: rerun with --launch to open the EBOOT in PPSSPP.")
        return 0
    try:
        proc = subprocess.Popen([emulator, str(eboot)], cwd=str(eboot.parent))
    except OSError as exc:
        print(f"LAUNCH FAILED: {exc}", file=sys.stderr)
        return 4
    print(f"LAUNCHED PPSSPP (pid {proc.pid}); confirm the game boots in the emulator window.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
