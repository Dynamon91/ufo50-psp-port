#!/usr/bin/env bash
# Bootstrap Rust + cargo-psp only. PSPSDK must be installed separately.
# This script intentionally fails early when network access is unavailable.
set -euo pipefail

if ! command -v curl >/dev/null 2>&1; then
  echo 'ERROR: curl is required to download the official rustup installer.' >&2
  exit 2
fi
if ! curl --fail --silent --show-error --location --max-time 10 https://sh.rustup.rs -o /dev/null; then
  echo 'ERROR: cannot reach https://sh.rustup.rs; check DNS/network access and retry.' >&2
  exit 3
fi

installer="$(mktemp)"
trap 'rm -f "$installer"' EXIT
curl --fail --silent --show-error --location --max-time 60 https://sh.rustup.rs -o "$installer"
sh "$installer" -y --default-toolchain none --profile minimal
export PATH="${CARGO_HOME:-$HOME/.cargo}/bin:$PATH"
rustup toolchain install nightly --profile minimal
rustup default nightly
cargo install cargo-psp

cat <<'MSG'
Rust nightly and cargo-psp installation completed.
PSPSDK is still required. Install/configure it for your host, ensure PSPDEV
points to its installation directory, then run: make toolchain-check
MSG
