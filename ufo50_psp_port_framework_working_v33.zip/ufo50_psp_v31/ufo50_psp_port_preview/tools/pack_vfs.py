#!/usr/bin/env python3
"""Pack port assets into a deterministic flat VFS blob: header + index + payload."""
import argparse,hashlib,struct
from pathlib import Path
MAGIC=b'UFOVFS01'

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('root'); ap.add_argument('out'); a=ap.parse_args()
    root,out=Path(a.root),Path(a.out); files=sorted(p for p in root.rglob('*') if p.is_file() and p.resolve() != out.resolve())
    entries=[]; payload=bytearray()
    for p in files:
        data=p.read_bytes(); path=p.relative_to(root).as_posix().encode(); off=len(payload); payload+=data; entries.append((path,off,len(data),hashlib.sha1(data).digest()[:8]))
    index=bytearray(); index += struct.pack('<I',len(entries))
    for path,off,size,h in entries: index += struct.pack('<III',len(path),off,size)+h+path
    header=struct.pack('<8sIIQ',MAGIC,1,len(index),len(payload))
    out.write_bytes(header+index+payload); print(f'{len(entries)} files, {len(payload)/1048576:.2f} MiB -> {out}')
if __name__=='__main__': main()
