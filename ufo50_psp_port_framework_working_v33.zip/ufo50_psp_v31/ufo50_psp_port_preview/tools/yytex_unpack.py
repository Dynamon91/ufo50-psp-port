#!/usr/bin/env python3
"""Decode GameMaker .yytex (BZ2 + GameMaker QOI/FIOQ) into PNG.
The 12-byte .yytex prefix is intentionally preserved/ignored; the BZ2 stream starts at byte 12.
"""
import argparse,bz2,struct
from pathlib import Path
from PIL import Image

def s(v,bits): return v-(1<<bits) if v&(1<<(bits-1)) else v

def decode(raw):
    if raw[:4]!=b'fioq': raise ValueError('Unsupported YYTex payload (expected fioq)')
    w,h,n=struct.unpack_from('<HHI',raw,4); p=raw[12:12+n]
    out=bytearray(w*h*4); idx=[(0,0,0,0)]*64
    r,g,b,a=0,0,0,255; pos=run=o=0
    while o<len(out):
        if run: run-=1
        else:
            x=p[pos]; pos+=1
            if x&0xc0==0: r,g,b,a=idx[x&63]
            elif x&0xe0==0x40: run=x&31
            elif x&0xe0==0x60: run=(((x&31)<<8)|p[pos])+32; pos+=1
            elif x&0xc0==0x80:
                r=(r+s((x>>4)&3,2))&255; g=(g+s((x>>2)&3,2))&255; b=(b+s(x&3,2))&255
            elif x&0xe0==0xc0:
                y=p[pos]; pos+=1; r=(r+s(x&31,5))&255; g=(g+s(y>>4,4))&255; b=(b+s(y&15,4))&255
            elif x&0xf0==0xe0:
                y,z=p[pos],p[pos+1]; pos+=2
                r=(r+s(x&15,4)*2)&255; g=(g+s((y>>2)&31,5)*2)&255; b=(b+s(((y&3)<<3)|(z>>5),5)*2)&255; a=(a+s(z&31,5))&255
            else:
                if x&8: r=p[pos]; pos+=1
                if x&4: g=p[pos]; pos+=1
                if x&2: b=p[pos]; pos+=1
                if x&1: a=p[pos]; pos+=1
            idx[(r^g^b^a)&63]=(r,g,b,a)
        out[o:o+4]=bytes((r,g,b,a)); o+=4
    return w,h,out

def unpack(path):
    b=Path(path).read_bytes(); return decode(bz2.decompress(b[12:]))

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('input'); ap.add_argument('-o','--output'); a=ap.parse_args()
    w,h,p=unpack(a.input); out=Path(a.output or Path(a.input).with_suffix('.png')); Image.frombytes('RGBA',(w,h),p).save(out); print(f'{w}x{h} -> {out}')
if __name__=='__main__': main()
