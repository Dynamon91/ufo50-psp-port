#include <bzlib.h>
#include <png.h>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <filesystem>
#include <fstream>
#include <iostream>
#include <string>
#include <vector>
namespace fs=std::filesystem;
static int8_t s(int v,int bits){int m=1<<(bits-1); return (int8_t)((v&m)?v-(1<<bits):v);}
struct Img{int w,h; std::vector<uint8_t> p;};
static Img decode(const std::vector<uint8_t>& raw){
 if(raw.size()<12||memcmp(raw.data(),"fioq",4)) throw std::runtime_error("bad fioq");
 int w=raw[4]|raw[5]<<8,h=raw[6]|raw[7]<<8; uint32_t n=raw[8]|raw[9]<<8|raw[10]<<16|raw[11]<<24;
 if(12ull+n>raw.size()) throw std::runtime_error("bad payload");
 const uint8_t* q=raw.data()+12; size_t pos=0; Img im{w,h,std::vector<uint8_t>((size_t)w*h*4)};
 uint8_t r=0,g=0,b=0,a=255, idx[64][4]{}; int run=0;
 for(size_t o=0;o<im.p.size();o+=4){
  if(run) --run; else {uint8_t x=q[pos++];
   if((x&0xc0)==0x00){memcpy(&r,idx[x&63],1);memcpy(&g,idx[x&63]+1,1);memcpy(&b,idx[x&63]+2,1);memcpy(&a,idx[x&63]+3,1);}
   else if((x&0xe0)==0x40) run=x&31;
   else if((x&0xe0)==0x60) run=((x&31)<<8)|q[pos++],run+=32;
   else if((x&0xc0)==0x80){r=(uint8_t)(r+s((x>>4)&3,2));g=(uint8_t)(g+s((x>>2)&3,2));b=(uint8_t)(b+s(x&3,2));}
   else if((x&0xe0)==0xc0){uint8_t y=q[pos++];r=(uint8_t)(r+s(x&31,5));g=(uint8_t)(g+s(y>>4,4));b=(uint8_t)(b+s(y&15,4));}
   else if((x&0xf0)==0xe0){uint8_t y=q[pos++],z=q[pos++];r=(uint8_t)(r+s(x&15,4)*2);g=(uint8_t)(g+s((y>>2)&31,5)*2);b=(uint8_t)(b+s(((y&3)<<3)|(z>>5),5)*2);a=(uint8_t)(a+s(z&31,5));}
   else {if(x&8)r=q[pos++];if(x&4)g=q[pos++];if(x&2)b=q[pos++];if(x&1)a=q[pos++];}
   int k=(r^g^b^a)&63; idx[k][0]=r;idx[k][1]=g;idx[k][2]=b;idx[k][3]=a;
  }
  im.p[o]=r;im.p[o+1]=g;im.p[o+2]=b;im.p[o+3]=a;
 }
 return im;
}
static std::vector<uint8_t> bz2(const fs::path& p){std::ifstream f(p,std::ios::binary);f.seekg(0,std::ios::end);size_t n=f.tellg();f.seekg(0);std::vector<uint8_t>b(n);f.read((char*)b.data(),n);if(n<=12)throw std::runtime_error("short yytex");
 unsigned cap=(unsigned)std::min<size_t>(n*20, 64ull*1024*1024); std::vector<uint8_t> out(cap); unsigned olen=cap; int rc=BZ2_bzBuffToBuffDecompress((char*)out.data(),&olen,(char*)b.data()+12,(unsigned)(n-12),0,0); if(rc!=BZ_OK){cap=256*1024*1024;out.resize(cap);olen=cap;rc=BZ2_bzBuffToBuffDecompress((char*)out.data(),&olen,(char*)b.data()+12,(unsigned)(n-12),0,0);} if(rc!=BZ_OK)throw std::runtime_error("bzip2 decompress failed");out.resize(olen);return out;}
static void write_png(const fs::path& p,const Img& im){FILE*f=fopen(p.string().c_str(),"wb");png_structp s=png_create_write_struct(PNG_LIBPNG_VER_STRING,nullptr,nullptr,nullptr);png_infop i=png_create_info_struct(s);if(setjmp(png_jmpbuf(s)))exit(2);png_init_io(s,f);png_set_IHDR(s,i,im.w,im.h,8,PNG_COLOR_TYPE_RGBA,PNG_INTERLACE_NONE,PNG_COMPRESSION_TYPE_DEFAULT,PNG_FILTER_TYPE_DEFAULT);png_write_info(s,i);std::vector<png_bytep> rows(im.h);for(int y=0;y<im.h;y++)rows[y]=(png_bytep)&im.p[(size_t)y*im.w*4];png_write_image(s,rows.data());png_write_end(s,nullptr);png_destroy_write_struct(&s,&i);fclose(f);}
int main(int argc,char**argv){if(argc<4){fprintf(stderr,"usage: yytex_convert SRC_DIR OUT_DIR MAX\n");return 1;}fs::path src=argv[1],out=argv[2];int max=atoi(argv[3]);size_t total=0,count=0;bool preview=false;for(auto&e:fs::recursive_directory_iterator(src))if(e.path().extension()==".yytex"){try{auto raw=bz2(e.path());auto im=decode(raw);double sc=std::min(1.0,max/(double)std::max(im.w,im.h));int w=std::max(1,(int)(im.w*sc+0.5)),h=std::max(1,(int)(im.h*sc+0.5));fs::path rel=fs::relative(e.path(),src).replace_extension(".raw");auto dest=out/rel;fs::create_directories(dest.parent_path());std::vector<uint16_t> q((size_t)w*h);for(int y=0;y<h;y++){int sy=(int)((long long)y*im.h/h);for(int x=0;x<w;x++){int sx=(int)((long long)x*im.w/w);auto*p=&im.p[((size_t)sy*im.w+sx)*4];q[(size_t)y*w+x]=(uint16_t)((p[3]>>4)<<12|(p[2]>>4)<<8|(p[1]>>4)<<4|(p[0]>>4));}}std::ofstream f(dest,std::ios::binary);f.write((char*)q.data(),q.size()*2);std::ofstream m(dest.replace_extension(".meta"));m<<"width="<<w<<"\nheight="<<h<<"\nformat=rgba4444\nbytes="<<q.size()*2<<"\n";total+=q.size()*2;count++;if(!preview){fs::path pp=out.parent_path().parent_path()/"docs/decoded_first_yytex.png";write_png(pp,im);preview=true;}}
catch(const std::exception&x){fprintf(stderr,"FAIL %s: %s\n",e.path().c_str(),x.what());return 2;}}
printf("converted=%zu raw_bytes=%zu (%.2f MiB)\n",count,total,total/1048576.0);}
