#!/usr/bin/env python3
"""Validate a packed VFS container without assuming game assets are present."""
import argparse
import struct
import sys
from pathlib import Path

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("path", type=Path)
    args = parser.parse_args()
    p = args.path
    if not p.is_file():
        print(f"VFS not found: {p} (asset packaging is optional until source assets are supplied)")
        return 0 if p.as_posix().endswith("assets/ufo50.vfs") else 2
    data = p.read_bytes()
    if len(data) < 8:
        print("VFS invalid: header is truncated", file=sys.stderr)
        return 2
    # Current packer uses a documented magic + entry count; avoid claiming
    # compatibility with any proprietary format.
    if data[:4] not in (b"U50V", b"UFS1"):
        print(f"VFS present ({len(data)} bytes); unknown/custom magic {data[:4]!r}; structural validation only")
        return 0
    print(f"VFS header accepted ({len(data)} bytes)")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
