#!/usr/bin/env python3
"""Bounds-check and list top-level chunks in a GameMaker FORM archive."""
import argparse
import struct
from pathlib import Path

HEADER_SIZE = 8
CHUNK_HEADER_SIZE = 8


def scan(path):
    """Return (declared_body_size, [(offset, tag, size, status), ...]).

    Rejects invalid headers and archives whose declared FORM body extends past
    EOF. A malformed chunk is reported rather than read beyond the container.
    Offsets in the result are absolute file offsets.
    """
    size = path.stat().st_size
    with path.open("rb") as f:
        header = f.read(HEADER_SIZE)
        if len(header) != HEADER_SIZE or header[:4] != b"FORM":
            raise ValueError("invalid FORM header")
        declared = struct.unpack("<I", header[4:8])[0]
        end = HEADER_SIZE + declared
        if end > size:
            raise ValueError(
                f"FORM body truncated: declared end {end}, file size {size}"
            )
        pos, chunks = HEADER_SIZE, []
        while pos < end:
            if end - pos < CHUNK_HEADER_SIZE:
                chunks.append((pos, "????", end - pos, "TRUNCATED_HEADER"))
                break
            f.seek(pos)
            chunk_header = f.read(CHUNK_HEADER_SIZE)
            tag = chunk_header[:4].decode("ascii", "replace")
            length = struct.unpack("<I", chunk_header[4:8])[0]
            data = pos + CHUNK_HEADER_SIZE
            chunk_end = data + length
            padded_end = chunk_end + (length & 1)
            if chunk_end > end or padded_end > end:
                chunks.append((pos, tag, length, "TRUNCATED"))
                break
            chunks.append((pos, tag, length, "ok"))
            pos = padded_end
        return declared, chunks


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("data_win", type=Path)
    args = ap.parse_args()
    declared, chunks = scan(args.data_win)
    print(f"FORM declared={declared} file={args.data_win.stat().st_size}")
    for offset, tag, length, status in chunks:
        print(f"{offset:08x} {tag} {length} {status}")
    print(f"chunk_count={len(chunks)}")
