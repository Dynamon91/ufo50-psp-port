#!/usr/bin/env python3
import argparse, pathlib, json
from PIL import Image

VRAM_BUDGET=4*1024*1024
def main():
    ap=argparse.ArgumentParser(); ap.add_argument("root"); a=ap.parse_args()
    total=0; rows=[]
    for p in pathlib.Path(a.root).rglob("*.png"):
        try:
            im=Image.open(p); b=im.width*im.height*2
            total+=b; rows.append((str(p),im.size,b))
        except: pass
    print(f"Estimated 16-bit texture VRAM: {total/1048576:.2f} MiB")
    print(f"Budget: {VRAM_BUDGET/1048576:.2f} MiB")
    if total>VRAM_BUDGET:
        print("WARNING: atlas streaming is required; do not upload all pages simultaneously.")
    pathlib.Path(a.root,"vram_budget.json").write_text(json.dumps(
        {"bytes":total,"budget_bytes":VRAM_BUDGET,"textures":rows},indent=2,default=str))
if __name__=="__main__": main()
