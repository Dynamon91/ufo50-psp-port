#!/usr/bin/env python3
import argparse, zipfile, pathlib, shutil

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("apk")
    ap.add_argument("out")
    a=ap.parse_args()
    out=pathlib.Path(a.out); out.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(a.apk) as z:
        for n in z.namelist():
            if n.startswith("assets/ufo50/") or n in ("AndroidManifest.xml",):
                target=out/n
                target.parent.mkdir(parents=True, exist_ok=True)
                with z.open(n) as src, open(target,"wb") as dst:
                    shutil.copyfileobj(src,dst,1024*1024)
    print(f"Extracted UFO 50 payload to {out}")

if __name__=="__main__": main()
