import struct
import tempfile
import unittest
from pathlib import Path
from scan_gm_form import scan


def make_form(chunks, trailing=b""):
    body = bytearray()
    for tag, data in chunks:
        body += tag.encode("ascii") + struct.pack("<I", len(data)) + data
        if len(data) & 1:
            body += b"\x00"
    body += trailing
    return b"FORM" + struct.pack("<I", len(body)) + body


class FormScannerTests(unittest.TestCase):
    def scan_bytes(self, data):
        with tempfile.TemporaryDirectory() as td:
            path = Path(td) / "data.win"
            path.write_bytes(data)
            return scan(path)

    def test_reads_even_and_odd_chunks(self):
        declared, chunks = self.scan_bytes(make_form([("GEN8", b"abcd"), ("STRG", b"xyz")]))
        self.assertEqual(declared, 24)
        self.assertEqual([c[1] for c in chunks], ["GEN8", "STRG"])
        self.assertTrue(all(c[3] == "ok" for c in chunks))

    def test_rejects_non_form(self):
        with self.assertRaisesRegex(ValueError, "invalid FORM header"):
            self.scan_bytes(b"NOTFORM!")

    def test_rejects_declared_body_past_eof(self):
        with self.assertRaisesRegex(ValueError, "FORM body truncated"):
            self.scan_bytes(b"FORM" + struct.pack("<I", 100) + b"GEN8")

    def test_reports_truncated_chunk_payload(self):
        body = b"GEN8" + struct.pack("<I", 20) + b"short"
        declared, chunks = self.scan_bytes(b"FORM" + struct.pack("<I", len(body)) + body)
        self.assertEqual(len(chunks), 1)
        self.assertEqual(chunks[0][3], "TRUNCATED")

    def test_reports_trailing_partial_chunk_header(self):
        declared, chunks = self.scan_bytes(make_form([], b"abc"))
        self.assertEqual(chunks[0][3], "TRUNCATED_HEADER")


if __name__ == "__main__":
    unittest.main(verbosity=2)
