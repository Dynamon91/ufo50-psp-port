#!/usr/bin/env python3
"""Host-side regression checks for PSP build/runtime integration contracts."""
from pathlib import Path
import unittest

ROOT = Path(__file__).resolve().parents[1]

class BuildContractTests(unittest.TestCase):
    def test_release_discovers_actual_eboot(self):
        m = (ROOT / "Makefile").read_text()
        self.assertIn("find target . -type f -name EBOOT.PBP", m)
        self.assertIn('cp "$$eboot" dist/EBOOT.PBP', m)
        self.assertIn("test -s dist/EBOOT.PBP", m)

    def test_host_test_has_optional_vfs_validation(self):
        m = (ROOT / "Makefile").read_text()
        self.assertIn("$(PYTHON) tools/validate_vfs.py assets/ufo50.vfs", m)
        self.assertTrue((ROOT / "tools/validate_vfs.py").is_file())

    def test_toolchain_diagnostic_is_honest(self):
        p = (ROOT / "tools/toolchain_status.py").read_text()
        self.assertIn("shutil.which", p)
        self.assertIn("PSP BUILD BLOCKED", p)
        self.assertIn("does not install tools", p)
        self.assertIn('"psp-config"', p)
        self.assertIn('os.environ.get("PSPDEV")', p)
        self.assertIn('"--json"', p)
        self.assertIn('"build_ready": not missing', p)
        self.assertIn("PPSSPP is useful for validation but not required to compile", p)

    def test_emulator_preflight_does_not_claim_boot_success(self):
        p = (ROOT / "tools/emulator_smoke.py").read_text()
        self.assertIn("PREFLIGHT ONLY", p)
        self.assertIn("--launch", p)
        self.assertIn("EBOOT MISSING/EMPTY", p)
        self.assertTrue((ROOT / "docs/EMULATOR_TESTING.md").is_file())

    def test_makefile_has_check_and_launch_targets(self):
        m = (ROOT / "Makefile").read_text()
        self.assertIn("emulator-check:", m)
        self.assertIn("emulator-launch:", m)
        self.assertIn("tools/emulator_smoke.py", m)

    def test_video_init_failure_exits_before_render_loop(self):
        main = (ROOT / "src/main.rs").read_text()
        self.assertIn("let video_status = unsafe { psp_video_init() };", main)
        self.assertIn("if video_status != 0", main)
        self.assertIn("sys::sceKernelExitGame()", main)

    def test_colors_use_explicit_psp_packing(self):
        main = (ROOT / "src/main.rs").read_text()
        self.assertIn("const fn color(r: u8, g: u8, b: u8, a: u8)", main)
        self.assertIn("color(16, 16, 24, 255)", main)
        self.assertNotIn("0xff101018", main)

    def test_ffi_read_lengths_are_bounded(self):
        vfs = (ROOT / "src/vfs.rs").read_text()
        self.assertGreaterEqual(vfs.count("(rc as usize) > cap"), 2)

if __name__ == "__main__":
    unittest.main(verbosity=2)
