use alloc::{string::String, vec::Vec};
use crate::vfs::Vfs;

#[derive(Clone, Copy)]
pub struct Chunk { pub tag: [u8;4], pub offset: u32, pub size: u32 }

fn le32(b: &[u8]) -> u32 { u32::from_le_bytes([b[0],b[1],b[2],b[3]]) }

pub struct DataWin { pub size: u32, pub chunks: Vec<Chunk> }

impl DataWin {
    pub fn open(path: &str) -> Option<Self> {
        let h = Vfs::read_range(path, 0, 12)?;
        if h.len() != 12 || &h[0..4] != b"FORM" { return None; }
        let size = le32(&h[4..8]).checked_add(8)?;
        let mut chunks = Vec::new();
        let mut off = 8u32;
        while off.checked_add(8)? <= size {
            let h = Vfs::read_range(path, off, 8)?;
            if h.len() != 8 { break; }
            let tag = [h[0],h[1],h[2],h[3]];
            let n = le32(&h[4..8]);
            let next = off.checked_add(8)?.checked_add(n)?;
            if next > size { return None; }
            chunks.push(Chunk { tag, offset: off, size: n });
            off = next;
        }
        Some(Self { size, chunks })
    }

    pub fn has(&self, name: &[u8;4]) -> bool { self.chunks.iter().any(|c| &c.tag == name) }
    pub fn tag_string(c: &Chunk) -> String {
        let mut s = String::new();
        for x in c.tag { s.push(x as char); }
        s
    }
}
