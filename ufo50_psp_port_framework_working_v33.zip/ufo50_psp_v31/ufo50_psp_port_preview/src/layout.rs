#![allow(dead_code)]

#[derive(Clone, Copy)]
pub struct Viewport {
    pub x: i32,
    pub y: i32,
    pub w: i32,
    pub h: i32,
    pub scale: f32,
}

pub fn fit(src_w: i32, src_h: i32, dst_w: i32, dst_h: i32) -> Viewport {
    let sx = dst_w as f32 / src_w as f32;
    let sy = dst_h as f32 / src_h as f32;
    let scale = if sx < sy { sx } else { sy };
    let w = (src_w as f32 * scale).round() as i32;
    let h = (src_h as f32 * scale).round() as i32;
    Viewport { x: (dst_w-w)/2, y: (dst_h-h)/2, w, h, scale }
}

pub fn map_point(v: Viewport, src_w: i32, src_h: i32, x: f32, y: f32) -> (i32, i32) {
    let px = v.x as f32 + x.clamp(0.0, src_w as f32) * v.scale;
    let py = v.y as f32 + y.clamp(0.0, src_h as f32) * v.scale;
    (px.round() as i32, py.round() as i32)
}
