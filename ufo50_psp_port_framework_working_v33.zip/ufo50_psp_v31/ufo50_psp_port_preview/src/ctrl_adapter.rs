//! Controller-frame normalization shared by the game runtime.

use crate::input_map::{map_buttons, ActionState};

#[derive(Clone, Copy, Debug, Default, PartialEq, Eq)]
pub struct CtrlSample {
    pub raw_buttons: u32,
    pub analog_x: u8,
    pub analog_y: u8,
}

#[derive(Clone, Copy, Debug, Default, PartialEq, Eq)]
pub struct CtrlFrame {
    pub now: ActionState,
    pub pressed_primary: bool,
    pub pressed_secondary: bool,
    pub pressed_pause: bool,
    pub pressed_system: bool,
    pub move_x: i8,
    pub move_y: i8,
}

fn axis(v: u8) -> i8 {
    let centered = v as i16 - 128;
    const DEAD: i16 = 18;
    if centered.abs() <= DEAD { return 0; }
    let sign = if centered < 0 { -1 } else { 1 };
    let magnitude = ((centered.abs() - DEAD) * 127 / (127 - DEAD)).clamp(0, 127);
    (sign * magnitude) as i8
}

pub fn sample_to_frame(sample: CtrlSample, previous: ActionState) -> CtrlFrame {
    let now = map_buttons(sample.raw_buttons);
    CtrlFrame {
        now,
        pressed_primary: now.primary && !previous.primary,
        pressed_secondary: now.secondary && !previous.secondary,
        pressed_pause: now.pause && !previous.pause,
        pressed_system: now.system && !previous.system,
        move_x: axis(sample.analog_x),
        move_y: axis(sample.analog_y),
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::input_map::{PSP_CROSS, PSP_CIRCLE, PSP_START};

    #[test]
    fn press_edges_fire_once() {
        let s = CtrlSample { raw_buttons: PSP_CROSS, ..Default::default() };
        let a = sample_to_frame(s, ActionState::default());
        assert!(a.pressed_primary);
        let b = sample_to_frame(s, a.now);
        assert!(!b.pressed_primary);
    }

    #[test]
    fn dead_zone_centers_stick() {
        let s = CtrlSample { analog_x: 128, analog_y: 128, ..Default::default() };
        let a = sample_to_frame(s, ActionState::default());
        assert_eq!((a.move_x, a.move_y), (0, 0));
    }

    #[test]
    fn cancel_and_pause_edges() {
        let s = CtrlSample { raw_buttons: PSP_CIRCLE | PSP_START, ..Default::default() };
        let a = sample_to_frame(s, ActionState::default());
        assert!(a.pressed_secondary && a.pressed_pause);
    }
}
