//! Minimal, deterministic GameMaker resource/runtime bridge.
//! This layer intentionally avoids executing host/Android code. It provides
//! PSP-native resource handles and a bounded bytecode dispatch surface.

use alloc::{collections::VecDeque, vec::Vec};

#[derive(Clone, Copy, Debug, Default)]
pub struct Value(pub i32);

#[derive(Clone, Copy, Debug, Default)]
pub struct Instance {
    pub id: u32,
    pub object_id: u32,
    pub x: i32,
    pub y: i32,
    pub active: bool,
}

pub struct Runtime {
    instances: Vec<Instance>,
    stack: Vec<Value>,
    frame: u64,
    max_instances: usize,
    next_instance_id: u32,
}

impl Runtime {
    pub fn new(max_instances: usize, stack_words: usize) -> Self {
        Self {
            instances: Vec::with_capacity(max_instances),
            stack: Vec::with_capacity(stack_words),
            frame: 0,
            max_instances,
            next_instance_id: 1,
        }
    }

    pub fn begin_frame(&mut self) {
        self.frame = self.frame.wrapping_add(1);
    }

    pub fn spawn(&mut self, object_id: u32, x: i32, y: i32) -> Option<u32> {
        // Respect the requested runtime budget, not Vec's allocator capacity.
        // `Vec::with_capacity(n)` may legally allocate more than `n`.
        // Reuse inactive storage slots so repeated create/destroy cycles do not
        // exhaust the lifetime budget. IDs remain monotonic and are never reused,
        // which prevents queued events for an old instance targeting its replacement.
        let id = self.next_instance_id;
        self.next_instance_id = self.next_instance_id.checked_add(1)?;
        let replacement = Instance { id, object_id, x, y, active: true };
        if let Some(slot) = self.instances.iter_mut().find(|instance| !instance.active) {
            *slot = replacement;
            return Some(id);
        }
        if self.instances.len() >= self.max_instances {
            // Roll back the ID counter because no instance was created.
            self.next_instance_id = id;
            return None;
        }
        self.instances.push(replacement);
        Some(id)
    }

    pub fn despawn(&mut self, id: u32) {
        if let Some(i) = self.instances.iter_mut().find(|v| v.id == id) {
            i.active = false;
        }
    }

    pub fn instances(&self) -> &[Instance] {
        &self.instances
    }

    /// Update an instance position by stable instance ID. Inactive or unknown
    /// instances are ignored, matching the bridge's safe no-op policy.
    pub fn set_position(&mut self, id: u32, x: i32, y: i32) -> bool {
        if let Some(instance) = self.instances.iter_mut().find(|v| v.id == id && v.active) {
            instance.x = x;
            instance.y = y;
            true
        } else {
            false
        }
    }

    /// Count currently active instances without allocating a temporary list.
    pub fn active_count(&self) -> usize {
        self.instances.iter().filter(|v| v.active).count()
    }

    /// Enqueue an event for each active instance; propagate capacity failures.
    pub fn enqueue_active_event(&self, queue: &mut EventQueue, kind: EventKind) -> Result<usize, RuntimeError> {
        let needed = self.active_count();
        if queue.remaining_capacity() < needed {
            return Err(RuntimeError::EventQueueCapacityExceeded);
        }
        let mut enqueued = 0;
        for instance in self.instances.iter().filter(|v| v.active) {
            queue.push(EventCall { instance_id: instance.id, object_id: instance.object_id, kind })?;
            enqueued += 1;
        }
        Ok(enqueued)
    }

    /// Consume queued events until one still targets a live instance whose
    /// object mapping matches the queued resource ID. Events left behind by
    /// despawned instances or stale mappings are discarded safely.
    pub fn next_live_event(&self, queue: &mut EventQueue) -> Option<EventCall> {
        while let Some(call) = queue.pop_next() {
            if self.instances.iter().any(|instance| {
                instance.id == call.instance_id
                    && instance.object_id == call.object_id
                    && instance.active
            }) {
                return Some(call);
            }
        }
        None
    }

    /// Bounded opcode bridge. Unknown instructions are deliberately rejected
    /// instead of falling through into unsafe host execution.
    pub fn dispatch(&mut self, opcode: u8, a: Value, b: Value) -> Result<Value, RuntimeError> {
        match opcode {
            0x00 => Ok(Value(0)),                  // nop
            0x01 => Ok(Value(a.0.wrapping_add(b.0))), // integer add
            0x02 => Ok(Value(a.0.wrapping_sub(b.0))), // integer subtract
            0x03 => Ok(Value(a.0.wrapping_mul(b.0))), // integer multiply
            0x04 => Ok(Value(if b.0 == 0 { 0 } else { a.0.checked_div(b.0).unwrap_or(0) })),
            _ => Err(RuntimeError::UnsupportedOpcode(opcode)),
        }
    }

    pub fn frame(&self) -> u64 { self.frame }
}

#[derive(Debug)]
pub enum RuntimeError {
    UnsupportedOpcode(u8),
    VariableCapacityExceeded,
    EventQueueCapacityExceeded,
}

/// Fixed-capacity variables keyed by stable resource IDs; avoids per-variable
/// heap allocations and string comparisons in the frame loop.
#[derive(Clone, Copy, Debug)]
pub struct Variable {
    pub name_id: u32,
    pub value: Value,
    pub used: bool,
}

pub struct VariableStore { entries: Vec<Variable> }

impl VariableStore {
    pub fn new(capacity: usize) -> Self {
        let mut entries = Vec::with_capacity(capacity);
        entries.resize(capacity, Variable { name_id: 0, value: Value(0), used: false });
        Self { entries }
    }

    pub fn set(&mut self, name_id: u32, value: Value) -> Result<(), RuntimeError> {
        if let Some(slot) = self.entries.iter_mut().find(|v| v.used && v.name_id == name_id) {
            slot.value = value;
            return Ok(());
        }
        if let Some(slot) = self.entries.iter_mut().find(|v| !v.used) {
            *slot = Variable { name_id, value, used: true };
            return Ok(());
        }
        Err(RuntimeError::VariableCapacityExceeded)
    }

    pub fn get(&self, name_id: u32) -> Option<Value> {
        self.entries.iter().find(|v| v.used && v.name_id == name_id).map(|v| v.value)
    }
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum EventKind { Create, Step, Draw, Destroy, RoomStart, RoomEnd }

#[derive(Clone, Copy, Debug)]
pub struct EventCall { pub instance_id: u32, pub object_id: u32, pub kind: EventKind }

/// Bounded queue for resource-mapped object events.
pub struct EventQueue { calls: VecDeque<EventCall>, max_calls: usize }

impl EventQueue {
    pub fn new(max_calls: usize) -> Self {
        Self { calls: VecDeque::with_capacity(max_calls), max_calls }
    }
    pub fn push(&mut self, call: EventCall) -> Result<(), RuntimeError> {
        if self.calls.len() >= self.max_calls { return Err(RuntimeError::EventQueueCapacityExceeded); }
        self.calls.push_back(call);
        Ok(())
    }
    /// Remove the oldest event in FIFO order. This avoids shifting the remaining
    /// queue entries when the runtime consumes one event at a time.
    pub fn pop_next(&mut self) -> Option<EventCall> { self.calls.pop_front() }
    /// Number of additional event calls that can be queued without allocation.
    pub fn remaining_capacity(&self) -> usize { self.max_calls.saturating_sub(self.calls.len()) }
    pub fn len(&self) -> usize { self.calls.len() }
    pub fn is_empty(&self) -> bool { self.calls.is_empty() }
    pub fn drain(&mut self) -> impl Iterator<Item = EventCall> + '_ { self.calls.drain(..) }
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn instance_budget_reuses_inactive_slots_without_reusing_ids() {
        let mut rt = Runtime::new(1, 4);
        let first = rt.spawn(10, 0, 0).expect("first instance fits budget");
        assert!(rt.spawn(11, 1, 1).is_none());
        rt.despawn(first);
        let replacement = rt.spawn(12, 2, 2).expect("inactive slot should be reusable");
        assert_ne!(first, replacement);
        assert_eq!(rt.instances().len(), 1);
        assert_eq!(rt.instances()[0].id, replacement);
        assert_eq!(rt.instances()[0].object_id, 12);
        assert_eq!(rt.active_count(), 1);
    }

    #[test]
    fn stale_event_cannot_target_reused_instance_slot() {
        let mut rt = Runtime::new(1, 4);
        let old_id = rt.spawn(10, 0, 0).unwrap();
        rt.despawn(old_id);
        let new_id = rt.spawn(10, 0, 0).unwrap();
        let mut queue = EventQueue::new(1);
        queue.push(EventCall { instance_id: old_id, object_id: 10, kind: EventKind::Step }).unwrap();
        assert!(rt.next_live_event(&mut queue).is_none());
        assert_ne!(old_id, new_id);
    }

    #[test]
    fn variable_store_updates_and_reads() {
        let mut vars = VariableStore::new(1);
        assert!(vars.set(7, Value(12)).is_ok());
        assert_eq!(vars.get(7).map(|v| v.0), Some(12));
        assert!(vars.set(8, Value(13)).is_err());
    }
    #[test]
    fn arithmetic_dispatch_is_deterministic_at_integer_boundaries() {
        let mut rt = Runtime::new(1, 4);
        assert_eq!(rt.dispatch(0x01, Value(i32::MAX), Value(1)).unwrap().0, i32::MIN);
        assert_eq!(rt.dispatch(0x04, Value(i32::MIN), Value(-1)).unwrap().0, 0);
        assert_eq!(rt.dispatch(0x04, Value(10), Value(0)).unwrap().0, 0);
    }
    #[test]
    fn instance_position_and_despawn_are_safe() {
        let mut rt = Runtime::new(2, 4);
        let id = rt.spawn(42, 10, 20).unwrap();
        assert_eq!(rt.active_count(), 1);
        assert!(rt.set_position(id, -5, 99));
        assert_eq!((rt.instances()[0].x, rt.instances()[0].y), (-5, 99));
        rt.despawn(id);
        assert_eq!(rt.active_count(), 0);
        assert!(!rt.set_position(id, 1, 2));
        assert!(!rt.set_position(999, 1, 2));
    }

    #[test]
    fn active_event_enqueue_skips_despawned_instances() {
        let mut rt = Runtime::new(3, 4);
        let first = rt.spawn(10, 0, 0).unwrap();
        rt.spawn(20, 0, 0).unwrap();
        rt.despawn(first);
        let mut q = EventQueue::new(2);
        assert_eq!(rt.enqueue_active_event(&mut q, EventKind::Step).unwrap(), 1);
        let events: Vec<_> = q.drain().collect();
        assert_eq!(events.len(), 1);
        assert_eq!(events[0].object_id, 20);
        assert_eq!(events[0].kind, EventKind::Step);
    }

    #[test]
    fn runtime_discards_events_for_despawned_or_mismatched_instances() {
        let mut rt = Runtime::new(3, 4);
        let dead = rt.spawn(10, 0, 0).unwrap();
        let live = rt.spawn(20, 0, 0).unwrap();
        rt.despawn(dead);
        let mut q = EventQueue::new(3);
        q.push(EventCall { instance_id: dead, object_id: 10, kind: EventKind::Step }).unwrap();
        q.push(EventCall { instance_id: live, object_id: 999, kind: EventKind::Draw }).unwrap();
        q.push(EventCall { instance_id: live, object_id: 20, kind: EventKind::Step }).unwrap();
        let event = rt.next_live_event(&mut q).expect("valid live event should survive");
        assert_eq!(event.instance_id, live);
        assert_eq!(event.object_id, 20);
        assert_eq!(event.kind, EventKind::Step);
        assert!(rt.next_live_event(&mut q).is_none());
    }

    #[test]
    fn event_queue_pops_in_fifo_order_and_reuses_capacity() {
        let mut q = EventQueue::new(2);
        let first = EventCall { instance_id: 1, object_id: 10, kind: EventKind::Create };
        let second = EventCall { instance_id: 2, object_id: 20, kind: EventKind::Step };
        assert!(q.push(first).is_ok());
        assert!(q.push(second).is_ok());
        assert_eq!(q.pop_next().map(|e| e.instance_id), Some(1));
        assert_eq!(q.remaining_capacity(), 1);
        assert!(q.push(first).is_ok(), "popping an event should free queue capacity");
        assert_eq!(q.pop_next().map(|e| e.instance_id), Some(2));
        assert_eq!(q.pop_next().map(|e| e.instance_id), Some(1));
        assert_eq!(q.pop_next().map(|e| e.instance_id), None);
        assert!(q.is_empty());
    }

    #[test]
    fn active_event_enqueue_is_atomic_when_queue_is_too_small() {
        let mut rt = Runtime::new(3, 4);
        rt.spawn(10, 0, 0).unwrap();
        rt.spawn(20, 0, 0).unwrap();
        let mut q = EventQueue::new(1);
        assert!(matches!(rt.enqueue_active_event(&mut q, EventKind::Step), Err(RuntimeError::EventQueueCapacityExceeded)));
        assert!(q.is_empty(), "failed batch must not leave a partial event list");
        assert_eq!(q.remaining_capacity(), 1);
    }

    #[test]
    fn event_queue_is_bounded_and_drains() {
        let mut q = EventQueue::new(1);
        let e = EventCall { instance_id: 1, object_id: 2, kind: EventKind::Step };
        assert!(q.push(e).is_ok());
        assert!(q.push(e).is_err());
        assert_eq!(q.drain().count(), 1);
    }

    #[test]
    fn variable_store_overwrite_does_not_consume_an_extra_slot() {
        let mut vars = VariableStore::new(1);
        assert!(vars.set(7, Value(1)).is_ok());
        assert!(vars.set(7, Value(2)).is_ok());
        assert_eq!(vars.get(7).map(|v| v.0), Some(2));
        assert!(vars.set(8, Value(3)).is_err());
    }

    #[test]
    fn zero_capacity_queues_and_stores_fail_safely() {
        let mut queue = EventQueue::new(0);
        let call = EventCall { instance_id: 1, object_id: 1, kind: EventKind::Create };
        assert!(matches!(queue.push(call), Err(RuntimeError::EventQueueCapacityExceeded)));
        assert!(queue.is_empty());
        let mut vars = VariableStore::new(0);
        assert!(matches!(vars.set(1, Value(1)), Err(RuntimeError::VariableCapacityExceeded)));
        assert_eq!(vars.get(1), None);
    }
}
