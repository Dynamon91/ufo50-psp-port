use alloc::{string::String, vec::Vec};

extern "C" {
    fn vfs_read_all(path: *const u8, len: usize, out: *mut u8, cap: usize) -> i32;
}

pub struct Vfs;

impl Vfs {
    pub fn read(path: &str) -> Option<Vec<u8>> {
        let bytes = path.as_bytes();
        let mut cap = 64 * 1024usize;
        for _ in 0..10 {
            let mut out = Vec::with_capacity(cap);
            let rc = unsafe { vfs_read_all(bytes.as_ptr(), bytes.len(), out.as_mut_ptr(), cap) };
            if rc < 0 { return None; }
            if (rc as usize) > cap { return None; }
            // C returns cap when the caller's buffer is too small.
            if rc as usize >= cap {
                cap = cap.checked_mul(2)?;
                continue;
            }
            unsafe { out.set_len(rc as usize); }
            return Some(out);
        }
        None
    }
}


extern "C" {
    fn vfs_read_range(path: *const u8, len: usize, offset: u32, out: *mut u8, cap: usize) -> i32;
}

impl Vfs {
    pub fn read_range(path: &str, offset: u32, cap: usize) -> Option<Vec<u8>> {
        if cap == 0 { return Some(Vec::new()); }
        let mut out = Vec::with_capacity(cap);
        let rc = unsafe { vfs_read_range(path.as_ptr(), path.len(), offset, out.as_mut_ptr(), cap) };
        if rc < 0 || (rc as usize) > cap { return None; }
        unsafe { out.set_len(rc as usize); }
        Some(out)
    }
}
