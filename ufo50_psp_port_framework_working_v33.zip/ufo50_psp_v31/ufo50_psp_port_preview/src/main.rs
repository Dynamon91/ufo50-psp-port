#![no_std]
#![no_main]

extern crate alloc;

mod layout;
mod vfs;
mod datawin;
mod gml_runtime;
mod ctrl_adapter;

use psp::sys;
use alloc::string::String;

extern "C" {
    fn psp_video_init() -> i32;
    fn psp_video_shutdown();
    fn psp_frame_begin();
    fn psp_frame_end();
    fn psp_draw_rect(x: i32, y: i32, w: i32, h: i32, rgba: u32);
    fn psp_poll_buttons(buttons: *mut u32, lx: *mut u8, ly: *mut u8) -> i32;
    fn psp_sleep_us(us: u32);
}

const W: i32 = 480;
const H: i32 = 272;

// The PSP GU expects packed colors as 0xAABBGGRR (R in the low byte).
// Keeping this conversion explicit avoids channel swaps from 0xRRGGBB literals.
const fn color(r: u8, g: u8, b: u8, a: u8) -> u32 {
    (r as u32) | ((g as u32) << 8) | ((b as u32) << 16) | ((a as u32) << 24)
}

#[derive(Default, Clone, Copy)]
struct Input {
    buttons: u32,
    lx: u8,
    ly: u8,
}

impl Input {
    fn pressed(&self, mask: u32) -> bool { self.buttons & mask != 0 }
}

use crate::input_map::{PSP_CIRCLE, PSP_CROSS, PSP_DOWN, PSP_LEFT, PSP_RIGHT,
    PSP_SELECT, PSP_SQUARE, PSP_START, PSP_TRIANGLE, PSP_UP};

const CROSS: u32 = PSP_CROSS;
const CIRCLE: u32 = PSP_CIRCLE;
const SQUARE: u32 = PSP_SQUARE;
const TRIANGLE: u32 = PSP_TRIANGLE;
const START: u32 = PSP_START;
const SELECT: u32 = PSP_SELECT;
const UP: u32 = PSP_UP;
const DOWN: u32 = PSP_DOWN;
const LEFT: u32 = PSP_LEFT;
const RIGHT: u32 = PSP_RIGHT;


#[psp::entry]
fn psp_main() {
    psp::enable_home_button();
    let video_status = unsafe { psp_video_init() };
    if video_status != 0 {
        // Do not enter a frame loop with an invalid EDRAM framebuffer.
        unsafe { sys::sceKernelExitGame(); }
        return;
    }

    let vp = layout::fit(480, 272, W, H);
    // The GameMaker archive is streamed: only 8/12-byte headers are read while
    // discovering resources, so the 53 MiB data.win never enters PSP RAM.
    let dw = datawin::DataWin::open("gamemaker/data.win");
    let mut input = Input::default();
    let mut frame: u32 = 0;
    let mut cursor_x: i32 = 220;
    let mut cursor_y: i32 = 120;

    loop {
        unsafe {
            psp_poll_buttons(&mut input.buttons, &mut input.lx, &mut input.ly);
            psp_frame_begin();

            // Porting shell: real game rendering replaces this layer once the
            // GameMaker data.win/YYTex runtime is translated.
            psp_draw_rect(0, 0, W, H, color(16, 16, 24, 255));
            psp_draw_rect(vp.x, vp.y, vp.w, vp.h, color(32, 32, 64, 255));
            if dw.is_some() { psp_draw_rect(24, 76, 6, 6, color(64, 255, 128, 255)); }

            // Centered analog mapping with a dead zone, supporting movement
            // in all directions instead of only the positive half-axis.
            let ax = input.lx as i32 - 128;
            let ay = input.ly as i32 - 128;
            let dx = if ax.abs() < 18 { 0 } else { ax / 24 };
            let dy = if ay.abs() < 18 { 0 } else { ay / 24 };
            cursor_x = (cursor_x + dx).clamp(0, W - 40);
            cursor_y = (cursor_y + dy).clamp(0, H - 32);
            if input.pressed(LEFT) { cursor_x = (cursor_x - 2).max(0); }
            if input.pressed(RIGHT) { cursor_x = (cursor_x + 2).min(W - 40); }
            if input.pressed(UP) { cursor_y = (cursor_y - 2).max(0); }
            if input.pressed(DOWN) { cursor_y = (cursor_y + 2).min(H - 32); }
            psp_draw_rect(cursor_x, cursor_y, 40, 32, color(255, 255, 255, 255));

            if input.pressed(CROSS) { psp_draw_rect(400, 220, 24, 24, color(0, 255, 0, 255)); }
            if input.pressed(CIRCLE) { psp_draw_rect(430, 220, 24, 24, color(255, 0, 0, 255)); }
            if input.pressed(SQUARE) { psp_draw_rect(370, 220, 24, 24, color(0, 255, 255, 255)); }
            if input.pressed(TRIANGLE) { psp_draw_rect(340, 220, 24, 24, color(255, 255, 0, 255)); }

            psp_frame_end();
            frame = frame.wrapping_add(1);
            psp_sleep_us(16_666);
        }

        if input.pressed(START) && input.pressed(SELECT) { break; }
        let _ = frame;
    }

    unsafe { psp_video_shutdown(); }
    unsafe { sys::sceKernelExitGame(); }
}
