#pragma once
#include <stdint.h>

int psp_video_init(void);
void psp_video_shutdown(void);
void psp_frame_begin(void);
void psp_frame_end(void);
void psp_draw_rect(int x, int y, int w, int h, uint32_t rgba);
int psp_poll_buttons(uint32_t *buttons, uint8_t *lx, uint8_t *ly);
void psp_sleep_us(uint32_t us);
