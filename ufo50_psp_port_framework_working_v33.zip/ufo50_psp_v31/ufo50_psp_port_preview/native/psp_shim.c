#include "psp_shim.h"
#include <pspkernel.h>
#include <pspdisplay.h>
#include <pspctrl.h>
#include <pspgu.h>
#include <pspge.h>
#include <pspgum.h>
#include <string.h>
#include <stdint.h>

PSP_MODULE_INFO("UFO50PSP", 0, 1, 0);
PSP_MAIN_THREAD_ATTR(PSP_THREAD_ATTR_USER);

// 512-pixel stride is required by the PSP GE. Two RGB565 buffers fit comfortably
// in the 2 MiB VRAM budget together with the command list.
static unsigned int __attribute__((aligned(16))) list[262144];
static uint16_t *fb[2];
static int framebuffer_ready = 0;

static void setup_gu(void) {
    // The display controller expects framebuffers in EDRAM/VRAM. Static C
    // arrays live in main RAM and can produce a black screen on real hardware.
    uint8_t *vram = (uint8_t *)sceGeEdramGetAddr();
    if (!vram) return;
    fb[0] = (uint16_t *)vram;
    fb[1] = (uint16_t *)(vram + (512u * 272u * sizeof(uint16_t)));
    framebuffer_ready = 1;

    sceGuInit();
    sceGuStart(GU_DIRECT, list);
    sceGuDrawBuffer(GU_PSM_5650, fb[0], 512);
    sceGuDispBuffer(480, 272, fb[1], 512);
    sceGuOffset(2048 - (480 / 2), 2048 - (272 / 2));
    sceGuViewport(2048, 2048, 480, 272);
    sceGuDepthRange(65535, 0);
    sceGuScissor(0, 0, 480, 272);
    sceGuEnable(GU_SCISSOR_TEST);
    sceGuDisable(GU_DEPTH_TEST);
    sceGuFinish();
    sceGuSync(0, 0);
    sceDisplayWaitVblankStart();
    sceGuDisplay(GU_TRUE);
}

int psp_video_init(void) {
    sceCtrlSetSamplingCycle(0);
    sceCtrlSetSamplingMode(PSP_CTRL_MODE_ANALOG);
    setup_gu();
    return framebuffer_ready ? 0 : -1;
}

void psp_video_shutdown(void) {
    sceGuDisplay(GU_FALSE);
    sceGuTerm();
}

void psp_frame_begin(void) {
    if (!framebuffer_ready) return;
    sceGuStart(GU_DIRECT, list);
    sceGuClearColor(0x00000000);
    sceGuClear(GU_COLOR_BUFFER_BIT);
}

void psp_draw_rect(int x, int y, int w, int h, uint32_t rgba) {
    if (!framebuffer_ready || w <= 0 || h <= 0) return;
    struct Vertex { uint32_t color; float x, y, z; };
    struct Vertex *v = (struct Vertex *)sceGuGetMemory(2 * sizeof(struct Vertex));
    v[0].color = rgba; v[0].x = (float)x;     v[0].y = (float)y;     v[0].z = 0;
    v[1].color = rgba; v[1].x = (float)(x+w); v[1].y = (float)(y+h); v[1].z = 0;
    sceGuDisable(GU_TEXTURE_2D);
    sceGuDrawArray(GU_SPRITES, GU_COLOR_8888|GU_VERTEX_32BITF|GU_TRANSFORM_2D, 2, 0, v);
}

void psp_frame_end(void) {
    if (!framebuffer_ready) return;
    sceGuFinish();
    sceGuSync(GU_SYNC_FINISH, GU_SYNC_WHAT_DONE);
    sceDisplayWaitVblankStart();
    sceGuSwapBuffers();
}

int psp_poll_buttons(uint32_t *buttons, uint8_t *lx, uint8_t *ly)
{
    SceCtrlData pad;
    sceCtrlReadBufferPositive(0, &pad, 1);
    *buttons = pad.Buttons;
    *lx = pad.Lx;
    *ly = pad.Ly;
    return 0;
}

void psp_sleep_us(uint32_t us) { sceKernelDelayThread(us); }
