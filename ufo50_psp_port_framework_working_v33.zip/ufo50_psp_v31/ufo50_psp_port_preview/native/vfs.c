#include "psp_shim.h"
#include <pspiofilemgr.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>

#define VFS_MAGIC "UFOVFS01"

// The index contains little-endian words at variable-length offsets. Avoid
// unaligned uint32_t pointer dereferences: MIPS/PSP may trap on those accesses.
static uint32_t read_le32(const uint8_t *p) {
    return (uint32_t)p[0] | ((uint32_t)p[1] << 8) |
           ((uint32_t)p[2] << 16) | ((uint32_t)p[3] << 24);
}

typedef struct {
    uint32_t path_len;
    uint32_t offset;
    uint32_t size;
    uint8_t hash[8];
} VfsEntry;

static SceUID open_vfs(void) {
    // Support standard Memory Stick installs, PSP Go internal storage, and
    // emulator/current-directory layouts. Try the exact path each call so the
    // port works when the user installs it under either supported device root.
    static const char *paths[] = {
        "ms0:/PSP/GAME/UFO50PSP/assets/ufo50.vfs",
        "ef0:/PSP/GAME/UFO50PSP/assets/ufo50.vfs",
        "./assets/ufo50.vfs"
    };
    for (unsigned i = 0; i < sizeof(paths) / sizeof(paths[0]); ++i) {
        SceUID fd = sceIoOpen(paths[i], PSP_O_RDONLY, 0);
        if (fd >= 0) return fd;
    }
    return -1;
}

static int read_exact(SceUID fd, void *dst, int n) {
    int got = sceIoRead(fd, dst, n);
    return got == n ? 0 : -1;
}

int vfs_read_all(const uint8_t *path, size_t len, uint8_t *out, size_t cap) {
    if (!path || !out || len == 0 || len > 255) return -1;

    SceUID fd = open_vfs();
    if (fd < 0) return -1;

    uint8_t header[24];
    if (read_exact(fd, header, sizeof(header)) < 0 || memcmp(header, VFS_MAGIC, 8) != 0) {
        sceIoClose(fd); return -1;
    }

    uint32_t version = read_le32(header + 8);
    uint32_t index_size = read_le32(header + 12);
    (void)version;
    if (index_size < 4 || index_size > 2 * 1024 * 1024) { sceIoClose(fd); return -1; }

    uint8_t *index = (uint8_t *)malloc(index_size);
    if (!index) { sceIoClose(fd); return -1; }
    if (read_exact(fd, index, (int)index_size) < 0) { free(index); sceIoClose(fd); return -1; }

    uint32_t count = read_le32(index);
    uint8_t *p = index + 4;
    uint8_t *end = index + index_size;
    int found = 0;
    uint32_t data_offset = 0, data_size = 0;

    for (uint32_t i = 0; i < count && p + 20 <= end; ++i) {
        uint32_t path_len = read_le32(p + 0);
        uint32_t off = read_le32(p + 4);
        uint32_t size = read_le32(p + 8);
        p += 20; // 12-byte header + 8-byte hash
        if (path_len > (uint32_t)(end - p)) break;
        if (path_len == len && memcmp(p, path, len) == 0) {
            data_offset = off; data_size = size; found = 1; break;
        }
        p += path_len;
    }

    free(index);
    if (!found) { sceIoClose(fd); return -1; }
    if ((size_t)data_size >= cap) { sceIoClose(fd); return (int)cap; }

    // Header (24) + index + payload-relative offset.
    SceOff absolute = (SceOff)24 + (SceOff)index_size + (SceOff)data_offset;
    if (sceIoLseek(fd, absolute, PSP_SEEK_SET) < 0) { sceIoClose(fd); return -1; }
    int got = sceIoRead(fd, out, (int)data_size);
    sceIoClose(fd);
    return got < 0 ? -1 : got;
}


int vfs_read_range(const uint8_t *path, size_t len, uint32_t range_offset,
                   uint8_t *out, size_t cap) {
    if (!path || !out || len == 0 || len > 255) return -1;
    SceUID fd = open_vfs();
    if (fd < 0) return -1;
    uint8_t header[24];
    if (read_exact(fd, header, sizeof(header)) < 0 || memcmp(header, VFS_MAGIC, 8) != 0) {
        sceIoClose(fd); return -1;
    }
    uint32_t index_size = read_le32(header + 12);
    if (index_size < 4 || index_size > 2 * 1024 * 1024) { sceIoClose(fd); return -1; }
    uint8_t *index = (uint8_t *)malloc(index_size);
    if (!index) { sceIoClose(fd); return -1; }
    if (read_exact(fd, index, (int)index_size) < 0) { free(index); sceIoClose(fd); return -1; }
    uint32_t count = read_le32(index);
    uint8_t *q = index + 4, *end = index + index_size;
    uint32_t data_offset = 0, data_size = 0; int found = 0;
    for (uint32_t i = 0; i < count && q + 20 <= end; ++i) {
        uint32_t path_len = read_le32(q + 0);
        uint32_t off = read_le32(q + 4);
        uint32_t size = read_le32(q + 8);
        q += 20;
        if (path_len > (uint32_t)(end - q)) break;
        if (path_len == len && memcmp(q, path, len) == 0) {
            data_offset = off; data_size = size; found = 1; break;
        }
        q += path_len;
    }
    free(index);
    if (!found || range_offset > data_size) { sceIoClose(fd); return -1; }
    uint32_t available = data_size - range_offset;
    if (cap > available) cap = available;
    SceOff absolute = (SceOff)24 + (SceOff)index_size + (SceOff)data_offset + range_offset;
    if (sceIoLseek(fd, absolute, PSP_SEEK_SET) < 0) { sceIoClose(fd); return -1; }
    int got = sceIoRead(fd, out, (int)cap);
    sceIoClose(fd);
    return got < 0 ? -1 : got;
}
