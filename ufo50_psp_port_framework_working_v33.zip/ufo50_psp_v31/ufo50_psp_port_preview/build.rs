fn main() {
    let mut b = cc::Build::new();
    b.file("native/psp_shim.c").file("native/vfs.c")
        .include("native")
        .flag("-O2")
        .flag("-G0")
        .flag("-fno-strict-aliasing");
    b.compile("pspshim");
}
