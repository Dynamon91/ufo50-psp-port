#!/bin/sh
set -eu
# Host-side archive tests can run without any PSP cross-toolchain.
make host-test
# Full build checks for the APK and all cross-compilers, then creates dist/EBOOT.PBP.
make release "APK=${APK:-../../UFO-50-v1.2-full-apkvision.apk}"
