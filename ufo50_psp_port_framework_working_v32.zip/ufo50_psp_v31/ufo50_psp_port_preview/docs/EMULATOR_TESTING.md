# PPSSPP testing workflow

PPSSPP is an optional validation step; it is not needed to compile the PSP EBOOT. Download it from the [official PPSSPP download page](https://www.ppsspp.org/download/). Avoid third-party repackaged installers.

After a real PSP build creates `dist/EBOOT.PBP`:

1. Run `make emulator-check` to verify that the EBOOT is non-empty and PPSSPP is discoverable on `PATH`.
2. Run `make emulator-launch` to ask PPSSPP to open the EBOOT.
3. Confirm visually that the application starts, renders, accepts input, and exits cleanly. Save logs/screenshots and note the PPSSPP version.
4. Treat a successful process launch as **not proof of a successful game boot**. Record a boot as verified only after inspecting the emulator screen.

The `tools/emulator_smoke.py` helper has exit statuses: `0` preflight passed or launch requested, `2` EBOOT missing/empty, `3` emulator not found, and `4` launch failed. It intentionally does not claim to observe the GUI or verify the game's behavior.

Current status for this repository: no EBOOT has been built in the current environment, and PPSSPP is not installed here. Consequently no emulator boot test has passed yet.
