#!/usr/bin/env python3
"""Host-side regression checks for PSP build/runtime integration contracts."""
from pathlib import Path
import unittest

ROOT = Path(__file__).resolve().parents[1]
APP = ROOT

class BuildContractTests(unittest.TestCase):
    def test_release_discovers_actual_eboot_instead_of_hardcoding_one_layout(self):
        makefile = (APP / "Makefile").read_text()
        self.assertIn("find target . -type f -name EBOOT.PBP", makefile)
        self.assertIn("cp \"$$eboot\" dist/EBOOT.PBP", makefile)
        self.assertIn("test -s dist/EBOOT.PBP", makefile)

    def test_host_test_uses_existing_vfs_validator_path(self):
        makefile = (APP / "Makefile").read_text()
        self.assertIn("$(PYTHON) tools/validate_vfs.py assets/ufo50.vfs", makefile)
        self.assertTrue((APP / "tools/validate_vfs.py").is_file())

    def test_toolchain_diagnostic_does_not_fake_missing_tools(self):
        checker = (APP / "tools/toolchain_status.py").read_text()
        self.assertIn("shutil.which", checker)
        self.assertIn("PSP BUILD BLOCKED", checker)
        self.assertIn("does not install tools", checker)


    def test_toolchain_diagnostic_checks_psp_config_and_pspdev(self):
        checker = (APP / "tools/toolchain_status.py").read_text()
        self.assertIn('"psp-config"', checker)
        self.assertIn('os.environ.get("PSPDEV")', checker)
        self.assertIn('"--json"', checker)
        self.assertIn('"build_ready": not missing', checker)

    def test_emulator_is_optional_for_build_readiness(self):
        checker = (APP / "tools/toolchain_status.py").read_text()
        self.assertIn("PPSSPP is useful for validation but not required to compile", checker)
        self.assertIn('REQUIRED = {"rustc", "cargo", "rustup", "psp-gcc", "psp-ar", "psp-config"}', checker)

    def test_emulator_preflight_does_not_claim_boot_success(self):
        helper = (APP / "tools/emulator_smoke.py").read_text()
        self.assertIn("PREFLIGHT ONLY", helper)
        self.assertIn("--launch", helper)
        self.assertIn("EBOOT MISSING/EMPTY", helper)
        self.assertTrue((APP / "docs/EMULATOR_TESTING.md").is_file())

    def test_makefile_exposes_emulator_check_and_launch_targets(self):
        makefile = (APP / "Makefile").read_text()
        self.assertIn("emulator-check:", makefile)
        self.assertIn("emulator-launch:", makefile)
        self.assertIn("tools/emulator_smoke.py", makefile)

    def test_video_init_failure_exits_before_render_loop(self):
        main = (APP / "src/main.rs").read_text()
        self.assertIn("let video_status = unsafe { psp_video_init() };", main)
        self.assertIn("if video_status != 0", main)
        self.assertIn("sys::sceKernelExitGame()", main)

    def test_colors_use_explicit_psp_packing(self):
        main = (APP / "src/main.rs").read_text()
        self.assertIn("const fn color(r: u8, g: u8, b: u8, a: u8)", main)
        self.assertIn("color(16, 16, 24, 255)", main)
        self.assertNotIn("0xff101018", main)

    def test_ffi_read_lengths_are_bounded_by_allocation(self):
        vfs = (APP / "src/vfs.rs").read_text()
        self.assertGreaterEqual(vfs.count("(rc as usize) > cap"), 2)

if __name__ == "__main__":
    unittest.main(verbosity=2)
