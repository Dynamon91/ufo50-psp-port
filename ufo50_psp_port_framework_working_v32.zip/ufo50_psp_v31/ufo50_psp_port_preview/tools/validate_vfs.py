#!/usr/bin/env python3
import struct, sys
from pathlib import Path
MAGIC=b'UFOVFS01'

p=Path(sys.argv[1] if len(sys.argv)>1 else 'assets/ufo50.vfs')
b=p.read_bytes()
assert b[:8]==MAGIC, 'bad VFS magic'
ver,index_size,payload_size=struct.unpack_from('<IIQ',b,8)
assert 24+index_size+payload_size==len(b), 'size mismatch'
pos=24
count=struct.unpack_from('<I',b,pos)[0]; pos+=4
names=[]
for _ in range(count):
    plen,off,size=struct.unpack_from('<III',b,pos); pos+=12
    h=b[pos:pos+8]; pos+=8
    name=b[pos:pos+plen].decode(); pos+=plen
    assert off+size<=payload_size, name
    names.append(name)
print(f'VFS OK: version={ver}, files={count}, index={index_size} bytes, payload={payload_size/1048576:.2f} MiB')
print(f'first={names[0] if names else "<empty>"}')
